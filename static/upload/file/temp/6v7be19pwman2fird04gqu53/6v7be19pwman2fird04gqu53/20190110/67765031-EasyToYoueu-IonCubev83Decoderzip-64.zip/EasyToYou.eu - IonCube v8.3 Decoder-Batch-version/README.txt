you need install last  framework to ioncube decoder work

http://www.microsoft.com/en-us/download/details.aspx?id=17718

see MANUAL  ( folder MANUAL manual.html) how decoder works 
http://easytoyou.eu/manual.html .