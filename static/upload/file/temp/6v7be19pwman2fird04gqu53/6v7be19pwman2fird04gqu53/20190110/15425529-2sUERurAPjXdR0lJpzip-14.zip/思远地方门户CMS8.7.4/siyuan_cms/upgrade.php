<?php

pdo_query('CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `attachment` varchar(100) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL,
  `openid` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `state` int(2) NOT NULL,
  `status` int(1) NOT NULL DEFAULT \'0\',
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_api` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) NOT NULL,
  `baidu_key` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_black_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL,
  `openid` varchar(200) NOT NULL,
  `beizhu` varchar(500) NOT NULL,
  `status` int(1) NOT NULL DEFAULT \'1\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_bottom_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `icon` varchar(100) NOT NULL DEFAULT \'\',
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  `xian` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_city` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_flash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `attachment` varchar(100) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_house` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `price` int(10) NOT NULL DEFAULT \'0\',
  `phone` varchar(32) NOT NULL DEFAULT \'\',
  `address` varchar(512) NOT NULL DEFAULT \'\',
  `province` varchar(50) NOT NULL DEFAULT \'\',
  `city` varchar(50) NOT NULL DEFAULT \'\',
  `district` varchar(50) NOT NULL DEFAULT \'\',
  `opentime` int(10) unsigned NOT NULL DEFAULT \'0\',
  `hotmsg` varchar(255) NOT NULL DEFAULT \'\',
  `longitude` varchar(255) NOT NULL DEFAULT \'\',
  `latitude` varchar(255) NOT NULL DEFAULT \'\',
  `thumb` varchar(255) NOT NULL DEFAULT \'\',
  `descimgs` mediumtext,
  `description` mediumtext,
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  `createtime` int(10) unsigned NOT NULL DEFAULT \'0\',
  `fenxiang` varchar(255) NOT NULL,
  `video` varchar(2000) NOT NULL,
  `biaoti` varchar(255) NOT NULL,
  `youhui` varchar(100) NOT NULL,
  `fenji` varchar(20) NOT NULL,
  `huxingimgs` mediumtext,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_house_kv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `houseid` int(11) NOT NULL DEFAULT \'0\',
  `key` varchar(512) NOT NULL DEFAULT \'\',
  `value` varchar(512) NOT NULL DEFAULT \'\',
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_houseid` (`houseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_house_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loupanid` int(10) DEFAULT NULL,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `laiyuan` varchar(50) NOT NULL DEFAULT \'\' COMMENT \'来源\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'点击积分奖励\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_huodong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `feiyong` int(10) NOT NULL DEFAULT \'0\',
  `num` int(10) NOT NULL DEFAULT \'0\',
  `tel` varchar(32) NOT NULL DEFAULT \'\',
  `address` varchar(512) NOT NULL DEFAULT \'\',
  `province` varchar(50) NOT NULL DEFAULT \'\',
  `city` varchar(50) NOT NULL DEFAULT \'\',
  `district` varchar(50) NOT NULL DEFAULT \'\',
  `lx` varchar(20) NOT NULL DEFAULT \'\',
  `longitude` varchar(255) NOT NULL DEFAULT \'\',
  `latitude` varchar(255) NOT NULL DEFAULT \'\',
  `descimgs` mediumtext,
  `body` text,
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  `createtime` int(10) unsigned NOT NULL DEFAULT \'0\',
  `fenxiang` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `video` varchar(2000) NOT NULL,
  `biaoti` varchar(255) NOT NULL,
  `ad` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `shop` varchar(20) NOT NULL,
  `blei` int(10) DEFAULT NULL,
  `slei` int(10) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `bm_time` int(10) DEFAULT NULL,
  `endtime` int(10) DEFAULT NULL,
  `xianzhi` int(10) NOT NULL DEFAULT \'1000\',
  `thumb` varchar(200) DEFAULT NULL,
  `music` varchar(200) DEFAULT NULL,
  `renshu` int(10) NOT NULL DEFAULT \'0\',
  `pinglun` int(10) NOT NULL DEFAULT \'0\',
  `yuedu` int(15) NOT NULL DEFAULT \'0\',
  `open` int(1) NOT NULL DEFAULT \'0\',
  `flash` int(1) NOT NULL DEFAULT \'0\',
  `shopid` int(10) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_huodong_fenlei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'所属帐号\',
  `nid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'关联导航id\',
  `name` varchar(50) NOT NULL COMMENT \'分类名称\',
  `parentid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'上级分类ID,0为第一级\',
  `displayorder` tinyint(3) unsigned NOT NULL DEFAULT \'0\' COMMENT \'排序\',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'是否开启\',
  `thumb` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_huodong_kv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `huodongid` int(11) NOT NULL DEFAULT \'0\',
  `key` varchar(512) NOT NULL DEFAULT \'\',
  `value` varchar(512) NOT NULL DEFAULT \'\',
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_houseid` (`huodongid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_huodong_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `huodongid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `openid` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_lookid` (`huodongid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_huodong_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `huodongid` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `tel` varchar(20) NOT NULL DEFAULT \'\',
  `body` varchar(1000) DEFAULT NULL,
  `ordersn` varchar(20) DEFAULT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `avatar` varchar(300) NOT NULL,
  `openid` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`),
  KEY `indx_lookid` (`huodongid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `ad_1` varchar(200) NOT NULL DEFAULT \'\',
  `ad_2` varchar(200) NOT NULL DEFAULT \'\',
  `ad_url_1` varchar(200) NOT NULL DEFAULT \'\',
  `ad_url_2` varchar(200) NOT NULL DEFAULT \'\',
  `qiandao` varchar(250) NOT NULL DEFAULT \'\',
  `city` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_index_flash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `thumb` varchar(200) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_index_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(250) NOT NULL DEFAULT \'\',
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `icon` varchar(200) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT \'1\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_index_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) NOT NULL,
  `news_logo` varchar(250) DEFAULT NULL,
  `news_name` varchar(20) NOT NULL DEFAULT \'最新资讯\',
  `news_num` int(10) NOT NULL DEFAULT \'5\',
  `news_xs` int(1) NOT NULL DEFAULT \'0\',
  `weixin_logo` varchar(250) NOT NULL,
  `weixin_name` varchar(20) NOT NULL DEFAULT \'微信头条\',
  `weixin_num` int(10) NOT NULL DEFAULT \'5\',
  `weixin_xs` int(1) NOT NULL DEFAULT \'0\',
  `huodong_logo` varchar(250) NOT NULL,
  `huodong_name` varchar(20) NOT NULL DEFAULT \'最新活动\',
  `huodong_num` int(10) NOT NULL DEFAULT \'5\',
  `huodong_xs` int(1) NOT NULL DEFAULT \'0\',
  `shop_logo` varchar(250) NOT NULL,
  `shop_name` varchar(20) NOT NULL DEFAULT \'星级商家\',
  `shop_num` int(10) NOT NULL DEFAULT \'8\',
  `shop_xs` int(1) NOT NULL DEFAULT \'0\',
  `house_logo` varchar(250) NOT NULL,
  `house_name` varchar(20) NOT NULL DEFAULT \'楼盘大全\',
  `house_num` int(10) NOT NULL DEFAULT \'5\',
  `house_xs` int(1) NOT NULL DEFAULT \'0\',
  `fang_logo` varchar(250) NOT NULL,
  `zufang_logo` varchar(250) NOT NULL,
  `job_logo` varchar(250) NOT NULL,
  `geren_logo` varchar(250) NOT NULL,
  `car_logo` varchar(250) NOT NULL,
  `ershou_logo` varchar(250) NOT NULL,
  `chongwu_logo` varchar(250) NOT NULL,
  `fang_name` varchar(20) NOT NULL DEFAULT \'房屋出售\',
  `zufang_name` varchar(20) NOT NULL DEFAULT \'房屋出租\',
  `job_name` varchar(20) NOT NULL DEFAULT \'企业招聘\',
  `geren_name` varchar(20) NOT NULL DEFAULT \'个人求职\',
  `car_name` varchar(20) NOT NULL DEFAULT \'车辆交易\',
  `ershou_name` varchar(20) NOT NULL DEFAULT \'二手交易\',
  `chongwu_name` varchar(20) NOT NULL DEFAULT \'宠物世界\',
  `fang_num` int(10) NOT NULL DEFAULT \'5\',
  `zufang_num` int(10) NOT NULL DEFAULT \'5\',
  `job_num` int(10) NOT NULL DEFAULT \'5\',
  `geren_num` int(10) NOT NULL DEFAULT \'5\',
  `car_num` int(10) NOT NULL DEFAULT \'5\',
  `ershou_num` int(10) NOT NULL DEFAULT \'5\',
  `chongwu_num` int(10) NOT NULL DEFAULT \'5\',
  `fang_xs` int(1) NOT NULL DEFAULT \'0\',
  `zufang_xs` int(1) NOT NULL DEFAULT \'0\',
  `car_xs` int(1) NOT NULL DEFAULT \'0\',
  `job_xs` int(1) NOT NULL DEFAULT \'0\',
  `geren_xs` int(1) NOT NULL DEFAULT \'0\',
  `ershou_xs` int(1) NOT NULL DEFAULT \'0\',
  `chongwu_xs` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `xian` int(1) NOT NULL DEFAULT \'0\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_nav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url_1` varchar(250) NOT NULL DEFAULT \'\',
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `url_2` varchar(250) NOT NULL,
  `icon_1` varchar(200) DEFAULT NULL,
  `icon_2` varchar(200) DEFAULT NULL,
  `bs` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT \'1\',
  `title_2` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'缩略图1\',
  `laiyuan` varchar(50) NOT NULL DEFAULT \'\' COMMENT \'来源\',
  `zuozhe` varchar(50) NOT NULL COMMENT \'作者\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `zan` int(11) NOT NULL,
  `flash` varchar(255) NOT NULL DEFAULT \'\',
  `descimgs` mediumtext,
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `cai` int(11) NOT NULL,
  `blei` int(10) NOT NULL,
  `slei` int(10) NOT NULL,
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `tuijian` int(2) NOT NULL DEFAULT \'0\',
  `weid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_news_fenlei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'所属帐号\',
  `nid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'关联导航id\',
  `name` varchar(50) NOT NULL COMMENT \'分类名称\',
  `parentid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'上级分类ID,0为第一级\',
  `displayorder` tinyint(3) unsigned NOT NULL DEFAULT \'0\' COMMENT \'排序\',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'是否开启\',
  `thumb` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_news_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `newsid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `openid` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_lookid` (`newsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_news_zhuanti` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recommendation` text NOT NULL,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `video` varchar(600) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `fenxiang` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'分享缩率图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `zan` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'点赞数\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `cai` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `title` varchar(300) DEFAULT NULL,
  `from_user` varchar(50) NOT NULL,
  `ordersn` varchar(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `paytype` tinyint(1) unsigned NOT NULL,
  `transid` varchar(30) NOT NULL DEFAULT \'0\',
  `remark` varchar(1000) NOT NULL DEFAULT \'\',
  `createtime` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_pk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `body` varchar(5000) NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'缩略图1\',
  `fenxiang` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'分享缩率图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `red` int(11) NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `weid` int(10) unsigned NOT NULL,
  `red_guandian` varchar(200) NOT NULL,
  `blue_guandian` varchar(200) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `blue` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_pk_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `newsid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`),
  KEY `indx_lookid` (`newsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_pk_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL,
  `openid` varchar(200) NOT NULL,
  `newsid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_quan` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) unsigned NOT NULL DEFAULT \'0\',
  `body` text,
  `openid` varchar(120) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `avatar` varchar(200) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_quan_flash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `thumb` varchar(200) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_quan_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(500) DEFAULT NULL,
  `qid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_quan_pinglun` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) unsigned NOT NULL DEFAULT \'0\',
  `body` text,
  `openid` varchar(120) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `pic` varchar(200) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `sai` varchar(100) DEFAULT NULL,
  `indexbg` varchar(300) DEFAULT NULL,
  `listbg` varchar(300) DEFAULT NULL,
  `fengmian` varchar(300) DEFAULT NULL,
  `topbg` varchar(300) DEFAULT NULL,
  `listbgcolor` varchar(30) NOT NULL DEFAULT \'#ec3c05\',
  `listcolor` varchar(30) NOT NULL DEFAULT \'#ffffff\',
  `fx_title` varchar(200) DEFAULT NULL,
  `fx_tubiao` varchar(250) DEFAULT NULL,
  `banquan_url` varchar(250) DEFAULT NULL,
  `banquan` varchar(100) DEFAULT NULL,
  `bg_color` varchar(30) NOT NULL DEFAULT \'#005192\',
  `bottom_color` varchar(30) NOT NULL DEFAULT \'#feda0d\',
  `nr_color` varchar(30) NOT NULL DEFAULT \'#057ac9\',
  `paddtop` int(10) NOT NULL DEFAULT \'400\',
  `size_color` varchar(30) DEFAULT \'#ffffff\',
  `baoming_1` varchar(50) DEFAULT NULL,
  `baoming_2` varchar(50) DEFAULT NULL,
  `baoming_3` varchar(50) DEFAULT NULL,
  `baoming_4` varchar(50) DEFAULT NULL,
  `baoming_5` varchar(50) DEFAULT NULL,
  `baoming_6` varchar(50) DEFAULT NULL,
  `baoming_7` varchar(50) DEFAULT NULL,
  `baoming_8` varchar(50) DEFAULT NULL,
  `baoming_tishi` text,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai_danye` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `sid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai_menu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\',
  `name` varchar(50) NOT NULL,
  `displayorder` tinyint(3) NOT NULL DEFAULT \'0\',
  `url` varchar(300) NOT NULL,
  `left` int(10) NOT NULL,
  `top` int(10) NOT NULL,
  `sid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `sid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `sid` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `avatar` varchar(300) NOT NULL,
  `openid` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `baoming_1` varchar(200) DEFAULT NULL,
  `baoming_2` varchar(200) DEFAULT NULL,
  `baoming_3` varchar(200) DEFAULT NULL,
  `baoming_4` varchar(200) DEFAULT NULL,
  `baoming_5` varchar(200) DEFAULT NULL,
  `baoming_6` varchar(200) DEFAULT NULL,
  `baoming_7` varchar(200) DEFAULT NULL,
  `baoming_8` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`),
  KEY `indx_lookid` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_sai_zanzhu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  `sid` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) NOT NULL,
  `qnsk` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `ad` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `weixin` varchar(100) NOT NULL,
  `openid` varchar(100) NOT NULL,
  `zhuangxiu_xiaoxi` varchar(100) NOT NULL,
  `tougao_xiaoxi` varchar(100) NOT NULL,
  `color` varchar(50) NOT NULL DEFAULT \'#fb9032\',
  `logo` varchar(300) NOT NULL,
  `qr` varchar(300) NOT NULL,
  `qnscode` varchar(200) NOT NULL,
  `qnym` varchar(200) NOT NULL,
  `qnak` varchar(200) NOT NULL,
  `apiclient_cert` varchar(500) DEFAULT NULL,
  `apiclient_key` varchar(500) DEFAULT NULL,
  `video` varchar(20) DEFAULT NULL,
  `tel_pay` decimal(10,2) NOT NULL DEFAULT \'0.00\',
  `xinxi_pay` decimal(10,2) NOT NULL DEFAULT \'0.00\',
  `shop_pay` decimal(10,2) NOT NULL DEFAULT \'0.00\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `ordersn` varchar(20) DEFAULT NULL,
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `openid` varchar(100) NOT NULL DEFAULT \'\',
  `tel` varchar(32) NOT NULL DEFAULT \'\',
  `address` varchar(512) NOT NULL DEFAULT \'\',
  `longitude` varchar(255) NOT NULL DEFAULT \'\',
  `latitude` varchar(255) NOT NULL DEFAULT \'\',
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  `fenxiang` varchar(255) NOT NULL,
  `video` varchar(2000) NOT NULL,
  `biaoti` varchar(255) NOT NULL,
  `ad` varchar(255) NOT NULL,
  `zi` varchar(2) NOT NULL,
  `color` varchar(20) NOT NULL DEFAULT \'#ec6c53\',
  `url` varchar(255) NOT NULL,
  `youhui` varchar(100) NOT NULL,
  `blei` int(10) NOT NULL,
  `slei` int(10) NOT NULL,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `descimgs` mediumtext,
  `thumb` varchar(250) NOT NULL,
  `flash` varchar(250) NOT NULL,
  `body` text,
  `yuedu` int(20) NOT NULL DEFAULT \'0\',
  `pinglun` int(10) NOT NULL DEFAULT \'0\',
  `status` int(1) NOT NULL DEFAULT \'0\',
  `yingye` varchar(100) DEFAULT NULL,
  `weixin` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_shop_fenlei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'所属帐号\',
  `nid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'关联导航id\',
  `name` varchar(50) NOT NULL COMMENT \'分类名称\',
  `parentid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'上级分类ID,0为第一级\',
  `displayorder` tinyint(3) unsigned NOT NULL DEFAULT \'0\' COMMENT \'排序\',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'是否开启\',
  `thumb` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_shop_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(500) DEFAULT NULL,
  `mid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_shop_kv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `shopid` int(11) NOT NULL DEFAULT \'0\',
  `key` varchar(512) NOT NULL DEFAULT \'\',
  `value` varchar(512) NOT NULL DEFAULT \'\',
  `displayorder` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_shopid` (`shopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_shop_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `shopid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `openid` varchar(200) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_lookid` (`shopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `tel` varchar(100) NOT NULL DEFAULT \'\',
  `weixin` varchar(100) NOT NULL DEFAULT \'\',
  `address` varchar(200) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT \'0\',
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `blei` int(10) NOT NULL,
  `slei` int(10) NOT NULL,
  `qr` varchar(300) DEFAULT NULL,
  `ordersn` varchar(20) DEFAULT NULL,
  `openid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tel_fenlei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'所属帐号\',
  `nid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'关联导航id\',
  `name` varchar(50) NOT NULL COMMENT \'分类名称\',
  `status` int(1) NOT NULL DEFAULT \'0\',
  `parentid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'上级分类ID,0为第一级\',
  `displayorder` tinyint(3) unsigned NOT NULL DEFAULT \'0\' COMMENT \'排序\',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'是否开启\',
  `thumb` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tougao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `weixin` varchar(100) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `yuedu` int(10) DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tougao_img` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pic` varchar(500) NOT NULL DEFAULT \'\',
  `mid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `title` varchar(200) NOT NULL DEFAULT \'\',
  `thumb` varchar(200) DEFAULT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `fx_title` varchar(300) DEFAULT NULL,
  `fx_tubiao` varchar(300) DEFAULT NULL,
  `top_pic` varchar(300) DEFAULT NULL,
  `ka_pic` varchar(300) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT \'0.00\',
  `time` varchar(300) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `body` text,
  `ka_pic_bottom` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tuan_gongsi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  `sid` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tuan_huodong` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `body` varchar(200) NOT NULL DEFAULT \'\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  `sid` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_tuan_pinpai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `thumb` varchar(100) NOT NULL DEFAULT \'\',
  `sid` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_vod` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `blei` int(11) DEFAULT NULL,
  `video` varchar(1000) NOT NULL,
  `url` varchar(300) NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'缩略图1\',
  `fenxiang` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'分享缩率图\',
  `laiyuan` varchar(50) NOT NULL DEFAULT \'\' COMMENT \'来源\',
  `zuozhe` varchar(50) NOT NULL COMMENT \'作者\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `zan` int(11) NOT NULL,
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `cai` int(11) NOT NULL,
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `tuijian` int(2) NOT NULL DEFAULT \'0\',
  `flash` int(1) NOT NULL DEFAULT \'0\',
  `weid` int(10) unsigned NOT NULL,
  `slei` int(11) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_vod_fenlei` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'所属帐号\',
  `nid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'关联导航id\',
  `name` varchar(50) NOT NULL COMMENT \'分类名称\',
  `thumb` varchar(200) NOT NULL,
  `status` int(1) DEFAULT \'0\',
  `parentid` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'上级分类ID,0为第一级\',
  `displayorder` tinyint(3) unsigned NOT NULL DEFAULT \'0\' COMMENT \'排序\',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT \'1\' COMMENT \'是否开启\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_vod_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `newsid` int(11) NOT NULL DEFAULT \'0\',
  `uid` int(10) unsigned NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `pid` int(11) NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL DEFAULT \'\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_lookid` (`newsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_vod_zhuanti` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recommendation` text NOT NULL,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `video` varchar(600) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `fenxiang` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'分享缩率图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `zan` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'点赞数\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `cai` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_weixin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `pic` varchar(200) DEFAULT NULL,
  `flash` varchar(200) DEFAULT NULL,
  `zhuti` varchar(100) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `weixin` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_weixin_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(300) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `zan` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'点赞数\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `flash` varchar(255) NOT NULL DEFAULT \'\',
  `descimgs` mediumtext,
  `cai` int(11) NOT NULL DEFAULT \'0\',
  `weixinid` int(10) DEFAULT NULL,
  `laiyuan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_weixin_news_pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(300) NOT NULL,
  `uniacid` int(11) NOT NULL DEFAULT \'0\',
  `newsid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(64) NOT NULL DEFAULT \'\',
  `content` text,
  `pid` int(11) NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL DEFAULT \'\',
  `status` tinyint(4) NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`uniacid`),
  KEY `indx_lookid` (`newsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `blei` int(10) DEFAULT NULL,
  `slei` int(10) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `chengse` varchar(50) DEFAULT NULL,
  `leixing` varchar(50) DEFAULT NULL,
  `biansu` varchar(50) DEFAULT NULL,
  `jiage` varchar(20) DEFAULT NULL,
  `pinpai` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_chongwu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `blei` int(10) DEFAULT NULL,
  `slei` int(10) DEFAULT NULL,
  `jiage` int(10) DEFAULT NULL,
  `leixing` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_ershou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `blei` int(10) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `slei` int(10) DEFAULT NULL,
  `jiage` int(12) NOT NULL DEFAULT \'0\',
  `xinjiu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_geren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `gongzuo` varchar(20) DEFAULT NULL,
  `qiye` varchar(100) DEFAULT NULL,
  `renshu` int(10) DEFAULT NULL,
  `zhiwei` varchar(100) DEFAULT NULL,
  `xueli` varchar(50) DEFAULT NULL,
  `gongzi` varchar(50) DEFAULT NULL,
  `uid` int(10) NOT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `blei` int(10) DEFAULT NULL,
  `slei` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_house` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `pic` text,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `huxing` varchar(100) DEFAULT NULL,
  `mianji` varchar(100) DEFAULT NULL,
  `louceng_1` varchar(10) DEFAULT NULL,
  `louceng_2` varchar(10) DEFAULT NULL,
  `zhuangxiu` varchar(100) DEFAULT NULL,
  `jiage` varchar(20) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(500) DEFAULT NULL,
  `mid` int(10) DEFAULT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `pic` text,
  `qiye` varchar(100) DEFAULT NULL,
  `renshu` int(10) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `zhiwei` varchar(100) DEFAULT NULL,
  `xueli` varchar(50) DEFAULT NULL,
  `gongzuo` varchar(20) DEFAULT NULL,
  `gongzi` varchar(50) DEFAULT NULL,
  `avatar` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_xinxi_zufang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `phone` varchar(20) NOT NULL DEFAULT \'\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `openid` varchar(100) NOT NULL,
  `ding` int(1) NOT NULL DEFAULT \'0\',
  `end_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `ding_time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `huxing` varchar(100) DEFAULT NULL,
  `mianji` varchar(100) DEFAULT NULL,
  `yuedu` int(10) DEFAULT NULL,
  `louceng_1` varchar(10) DEFAULT NULL,
  `zhuangxiu` varchar(100) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `louceng_2` varchar(10) DEFAULT NULL,
  `pic` text,
  `jiage` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `zujin` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhibo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) unsigned NOT NULL DEFAULT \'0\',
  `title` varchar(320) DEFAULT NULL,
  `thumb` varchar(200) DEFAULT NULL,
  `zhiboid` varchar(50) DEFAULT NULL,
  `qiniu_tuiliu` varchar(300) DEFAULT NULL,
  `qiniu_play` varchar(300) DEFAULT NULL,
  `uid` varchar(50) DEFAULT NULL,
  `appkey` varchar(100) DEFAULT NULL,
  `renshu` int(11) DEFAULT \'0\',
  `lx` int(1) DEFAULT \'0\',
  `zb_lx` int(1) DEFAULT \'0\',
  `body` text,
  `starttime` int(10) NOT NULL DEFAULT \'0\',
  `endtime` int(10) NOT NULL DEFAULT \'0\',
  `shua` int(10) NOT NULL DEFAULT \'30\',
  `fenxiang` varchar(200) DEFAULT NULL,
  `zhibo_url` varchar(300) DEFAULT NULL,
  `tuwen_url` varchar(300) DEFAULT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `zan` int(11) NOT NULL DEFAULT \'0\',
  `cai` int(11) NOT NULL DEFAULT \'0\',
  `yuedu` int(11) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhibo_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL,
  `openid` varchar(200) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `state` int(2) NOT NULL,
  `uid` int(11) NOT NULL,
  `zid` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhibo_body` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) unsigned NOT NULL DEFAULT \'0\',
  `body` text,
  `username` varchar(64) DEFAULT NULL,
  `avatar` varchar(250) DEFAULT NULL,
  `time` int(10) NOT NULL DEFAULT \'0\',
  `zan` int(10) NOT NULL DEFAULT \'0\',
  `openid` varchar(100) DEFAULT NULL,
  `pic` text,
  `vod` varchar(500) DEFAULT NULL,
  `zhiboid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhibo_pinglun` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(11) unsigned NOT NULL DEFAULT \'0\',
  `body` varchar(500) DEFAULT NULL,
  `username` varchar(64) DEFAULT NULL,
  `avatar` varchar(250) DEFAULT NULL,
  `time` int(10) NOT NULL DEFAULT \'0\',
  `zhiboid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_baojia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `tel` varchar(100) DEFAULT NULL,
  `body` varchar(500) DEFAULT NULL,
  `xiaoqu` varchar(100) DEFAULT NULL,
  `mianji` varchar(100) DEFAULT NULL,
  `time` int(10) NOT NULL DEFAULT \'0\',
  `gongsi` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_flash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `url` varchar(200) NOT NULL DEFAULT \'\',
  `attachment` varchar(100) NOT NULL DEFAULT \'\',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_gonglve` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `pic` varchar(200) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `ad` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_gonglve_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `content` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `gonglveid` int(10) DEFAULT NULL,
  `n_title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_gongsi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(200) NOT NULL DEFAULT \'\',
  `pic` varchar(200) DEFAULT NULL,
  `body` text,
  `displayorder` int(10) NOT NULL DEFAULT \'0\',
  `ad` varchar(100) DEFAULT NULL,
  `thumb` varchar(200) DEFAULT NULL,
  `gongdi` int(10) DEFAULT \'0\',
  `anli` int(10) DEFAULT \'0\',
  `yezhu` int(10) DEFAULT \'0\',
  `openid` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_gongsi_anli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT \'\',
  `body` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `yuedu` int(10) unsigned NOT NULL DEFAULT \'0\' COMMENT \'阅读数\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `gongsiid` int(10) DEFAULT NULL,
  `gongsi` varchar(50) DEFAULT NULL,
  `sheji` varchar(100) DEFAULT NULL,
  `huxing` varchar(200) DEFAULT NULL,
  `shejiid` int(10) DEFAULT NULL,
  `xiaoqu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_gongsi_sheji` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `body` text NOT NULL,
  `thumb` varchar(1024) NOT NULL DEFAULT \'\' COMMENT \'内容配图\',
  `displayorder` int(10) unsigned NOT NULL DEFAULT \'0\',
  `time` int(10) unsigned NOT NULL DEFAULT \'0\',
  `pinglun` int(11) NOT NULL DEFAULT \'0\',
  `gongsiid` int(10) DEFAULT NULL,
  `touxiang` varchar(200) DEFAULT NULL,
  `gongsi` varchar(100) DEFAULT NULL,
  `tedian` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_yanfang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `tel` varchar(100) DEFAULT NULL,
  `body` varchar(500) DEFAULT NULL,
  `xiaoqu` varchar(100) DEFAULT NULL,
  `mianji` varchar(100) DEFAULT NULL,
  `time` int(10) NOT NULL DEFAULT \'0\',
  `gongsi` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
CREATE TABLE IF NOT EXISTS `ims_siyuan_cms_zhuangxiu_yuyue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weid` int(11) NOT NULL DEFAULT \'0\',
  `name` varchar(50) NOT NULL DEFAULT \'\',
  `tel` varchar(100) DEFAULT NULL,
  `body` varchar(500) DEFAULT NULL,
  `xiaoqu` varchar(100) DEFAULT NULL,
  `mianji` varchar(100) DEFAULT NULL,
  `time` int(10) NOT NULL DEFAULT \'0\',
  `gongsi` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT \'0\',
  PRIMARY KEY (`id`),
  KEY `indx_uniacid` (`weid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
');
if (pdo_tableexists('siyuan_cms_ad')) {
    if (!pdo_fieldexists('siyuan_cms_ad', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_ad') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_ad')) {
    if (!pdo_fieldexists('siyuan_cms_ad', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_ad') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_ad')) {
    if (!pdo_fieldexists('siyuan_cms_ad', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_ad') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_ad')) {
    if (!pdo_fieldexists('siyuan_cms_ad', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_ad') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_ad')) {
    if (!pdo_fieldexists('siyuan_cms_ad', 'attachment')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_ad') . ' ADD `attachment` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `uniacid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `name` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `username` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `tel` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'state')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `state` int(2) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_admin')) {
    if (!pdo_fieldexists('siyuan_cms_admin', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_admin') . ' ADD `uid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_api')) {
    if (!pdo_fieldexists('siyuan_cms_api', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_api') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_api')) {
    if (!pdo_fieldexists('siyuan_cms_api', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_api') . ' ADD `weid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_api')) {
    if (!pdo_fieldexists('siyuan_cms_api', 'baidu_key')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_api') . ' ADD `baidu_key` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_api')) {
    if (!pdo_fieldexists('siyuan_cms_api', 'city')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_api') . ' ADD `city` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_black_list')) {
    if (!pdo_fieldexists('siyuan_cms_black_list', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_black_list') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_black_list')) {
    if (!pdo_fieldexists('siyuan_cms_black_list', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_black_list') . ' ADD `weid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_black_list')) {
    if (!pdo_fieldexists('siyuan_cms_black_list', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_black_list') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_black_list')) {
    if (!pdo_fieldexists('siyuan_cms_black_list', 'beizhu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_black_list') . ' ADD `beizhu` varchar(500) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_black_list')) {
    if (!pdo_fieldexists('siyuan_cms_black_list', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_black_list') . ' ADD `status` int(1) NOT NULL  DEFAULT 1 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'icon')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `icon` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_bottom_menu')) {
    if (!pdo_fieldexists('siyuan_cms_bottom_menu', 'xian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_bottom_menu') . ' ADD `xian` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_city')) {
    if (!pdo_fieldexists('siyuan_cms_city', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_city') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_flash')) {
    if (!pdo_fieldexists('siyuan_cms_flash', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_flash') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_flash')) {
    if (!pdo_fieldexists('siyuan_cms_flash', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_flash') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_flash')) {
    if (!pdo_fieldexists('siyuan_cms_flash', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_flash') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_flash')) {
    if (!pdo_fieldexists('siyuan_cms_flash', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_flash') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_flash')) {
    if (!pdo_fieldexists('siyuan_cms_flash', 'attachment')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_flash') . ' ADD `attachment` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'price')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `price` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `phone` varchar(32) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `address` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'province')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `province` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'city')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `city` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'district')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `district` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'opentime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `opentime` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'hotmsg')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `hotmsg` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'longitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `longitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'latitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `latitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `thumb` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'descimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `descimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'description')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `description` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'createtime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `createtime` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `fenxiang` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `video` varchar(2000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'biaoti')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `biaoti` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'youhui')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `youhui` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'fenji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `fenji` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house')) {
    if (!pdo_fieldexists('siyuan_cms_house', 'huxingimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house') . ' ADD `huxingimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'houseid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `houseid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'key')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `key` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'value')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `value` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_kv')) {
    if (!pdo_fieldexists('siyuan_cms_house_kv', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_kv') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'loupanid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `loupanid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'laiyuan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `laiyuan` varchar(50) NOT NULL   COMMENT \'来源\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'点击积分奖励\';');
    }
}
if (pdo_tableexists('siyuan_cms_house_news')) {
    if (!pdo_fieldexists('siyuan_cms_house_news', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_house_news') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'feiyong')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `feiyong` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `num` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `tel` varchar(32) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `address` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'province')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `province` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'city')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `city` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'district')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `district` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'lx')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `lx` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'longitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `longitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'latitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `latitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'descimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `descimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'createtime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `createtime` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `fenxiang` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `pic` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `video` varchar(2000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'biaoti')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `biaoti` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'ad')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `ad` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `url` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'shop')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `shop` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `blei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `slei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `time` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'bm_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `bm_time` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'endtime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `endtime` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'xianzhi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `xianzhi` int(10) NOT NULL  DEFAULT 1000 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `thumb` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'music')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `music` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'renshu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `renshu` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `pinglun` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `yuedu` int(15) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'open')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `open` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `flash` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_huodong', 'shopid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong') . ' ADD `shopid` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'所属帐号\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'nid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `nid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'关联导航id\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'分类名称\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'parentid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `parentid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'上级分类ID,0为第一级\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `displayorder` tinyint(3) unsigned NOT NULL  DEFAULT 0 COMMENT \'排序\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'enabled')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `enabled` tinyint(1) unsigned NOT NULL  DEFAULT 1 COMMENT \'是否开启\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_fenlei', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_fenlei') . ' ADD `thumb` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'huodongid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `huodongid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'key')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `key` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'value')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `value` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_kv')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_kv', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_kv') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'huodongid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `huodongid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `pid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'huodongid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `huodongid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `tel` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'ordersn')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `ordersn` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_huodong_users')) {
    if (!pdo_fieldexists('siyuan_cms_huodong_users', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_huodong_users') . ' ADD `username` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'ad_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `ad_1` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'ad_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `ad_2` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'ad_url_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `ad_url_1` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'ad_url_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `ad_url_2` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'qiandao')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `qiandao` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index')) {
    if (!pdo_fieldexists('siyuan_cms_index', 'city')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index') . ' ADD `city` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_flash')) {
    if (!pdo_fieldexists('siyuan_cms_index_flash', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_flash') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_flash')) {
    if (!pdo_fieldexists('siyuan_cms_index_flash', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_flash') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_flash')) {
    if (!pdo_fieldexists('siyuan_cms_index_flash', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_flash') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_flash')) {
    if (!pdo_fieldexists('siyuan_cms_index_flash', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_flash') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_flash')) {
    if (!pdo_fieldexists('siyuan_cms_index_flash', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_flash') . ' ADD `thumb` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `url` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'icon')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `icon` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_nav')) {
    if (!pdo_fieldexists('siyuan_cms_index_nav', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_nav') . ' ADD `status` int(1) NOT NULL  DEFAULT 1 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `weid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'news_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `news_logo` varchar(250)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'news_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `news_name` varchar(20) NOT NULL  DEFAULT 最新资讯 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'news_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `news_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'news_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `news_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'weixin_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `weixin_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'weixin_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `weixin_name` varchar(20) NOT NULL  DEFAULT 微信头条 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'weixin_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `weixin_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'weixin_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `weixin_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'huodong_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `huodong_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'huodong_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `huodong_name` varchar(20) NOT NULL  DEFAULT 最新活动 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'huodong_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `huodong_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'huodong_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `huodong_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'shop_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `shop_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'shop_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `shop_name` varchar(20) NOT NULL  DEFAULT 星级商家 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'shop_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `shop_num` int(10) NOT NULL  DEFAULT 8 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'shop_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `shop_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'house_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `house_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'house_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `house_name` varchar(20) NOT NULL  DEFAULT 楼盘大全 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'house_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `house_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'house_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `house_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'fang_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `fang_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'zufang_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `zufang_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'job_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `job_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'geren_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `geren_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'car_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `car_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'ershou_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `ershou_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'chongwu_logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `chongwu_logo` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'fang_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `fang_name` varchar(20) NOT NULL  DEFAULT 房屋出售 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'zufang_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `zufang_name` varchar(20) NOT NULL  DEFAULT 房屋出租 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'job_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `job_name` varchar(20) NOT NULL  DEFAULT 企业招聘 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'geren_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `geren_name` varchar(20) NOT NULL  DEFAULT 个人求职 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'car_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `car_name` varchar(20) NOT NULL  DEFAULT 车辆交易 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'ershou_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `ershou_name` varchar(20) NOT NULL  DEFAULT 二手交易 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'chongwu_name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `chongwu_name` varchar(20) NOT NULL  DEFAULT 宠物世界 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'fang_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `fang_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'zufang_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `zufang_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'job_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `job_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'geren_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `geren_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'car_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `car_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'ershou_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `ershou_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'chongwu_num')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `chongwu_num` int(10) NOT NULL  DEFAULT 5 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'fang_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `fang_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'zufang_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `zufang_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'car_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `car_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'job_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `job_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'geren_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `geren_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'ershou_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `ershou_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_index_set')) {
    if (!pdo_fieldexists('siyuan_cms_index_set', 'chongwu_xs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_index_set') . ' ADD `chongwu_xs` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'xian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `xian` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_menu')) {
    if (!pdo_fieldexists('siyuan_cms_menu', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_menu') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'url_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `url_1` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'url_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `url_2` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'icon_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `icon_1` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'icon_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `icon_2` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'bs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `bs` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `status` int(1) NOT NULL  DEFAULT 1 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_nav')) {
    if (!pdo_fieldexists('siyuan_cms_nav', 'title_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_nav') . ' ADD `title_2` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'缩略图1\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'laiyuan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `laiyuan` varchar(50) NOT NULL   COMMENT \'来源\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'zuozhe')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `zuozhe` varchar(50) NOT NULL   COMMENT \'作者\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `zan` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `flash` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'descimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `descimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `cai` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `blei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `slei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'tuijian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `tuijian` int(2) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news')) {
    if (!pdo_fieldexists('siyuan_cms_news', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news') . ' ADD `weid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'所属帐号\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'nid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `nid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'关联导航id\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'分类名称\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'parentid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `parentid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'上级分类ID,0为第一级\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `displayorder` tinyint(3) unsigned NOT NULL  DEFAULT 0 COMMENT \'排序\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'enabled')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `enabled` tinyint(1) unsigned NOT NULL  DEFAULT 1 COMMENT \'是否开启\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_news_fenlei', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_fenlei') . ' ADD `thumb` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'newsid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `newsid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `pid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_news_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'recommendation')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `recommendation` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `video` varchar(600) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `fenxiang` varchar(1024) NOT NULL   COMMENT \'分享缩率图\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `zan` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'点赞数\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_news_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_news_zhuanti', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_news_zhuanti') . ' ADD `cai` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'price')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `price` decimal(10,2) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `title` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'from_user')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `from_user` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'ordersn')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `ordersn` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'paytype')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `paytype` tinyint(1) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'transid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `transid` varchar(30) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'remark')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `remark` varchar(1000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'createtime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `createtime` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_order')) {
    if (!pdo_fieldexists('siyuan_cms_order', 'type')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_order') . ' ADD `type` varchar(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `body` varchar(5000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'缩略图1\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `fenxiang` varchar(1024) NOT NULL   COMMENT \'分享缩率图\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'red')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `red` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'red_guandian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `red_guandian` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'blue_guandian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `blue_guandian` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `url` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk')) {
    if (!pdo_fieldexists('siyuan_cms_pk', 'blue')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk') . ' ADD `blue` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'newsid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `newsid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_pk_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_user')) {
    if (!pdo_fieldexists('siyuan_cms_pk_user', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_user') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_user')) {
    if (!pdo_fieldexists('siyuan_cms_pk_user', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_user') . ' ADD `weid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_user')) {
    if (!pdo_fieldexists('siyuan_cms_pk_user', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_user') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_pk_user')) {
    if (!pdo_fieldexists('siyuan_cms_pk_user', 'newsid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_pk_user') . ' ADD `newsid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `id` int(11) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `weid` int(11) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `openid` varchar(120)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `avatar` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'type')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `type` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan')) {
    if (!pdo_fieldexists('siyuan_cms_quan', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan') . ' ADD `time` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_flash')) {
    if (!pdo_fieldexists('siyuan_cms_quan_flash', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_flash') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_flash')) {
    if (!pdo_fieldexists('siyuan_cms_quan_flash', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_flash') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_flash')) {
    if (!pdo_fieldexists('siyuan_cms_quan_flash', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_flash') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_flash')) {
    if (!pdo_fieldexists('siyuan_cms_quan_flash', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_flash') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_flash')) {
    if (!pdo_fieldexists('siyuan_cms_quan_flash', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_flash') . ' ADD `thumb` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_img')) {
    if (!pdo_fieldexists('siyuan_cms_quan_img', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_img') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_img')) {
    if (!pdo_fieldexists('siyuan_cms_quan_img', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_img') . ' ADD `pic` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_img')) {
    if (!pdo_fieldexists('siyuan_cms_quan_img', 'qid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_img') . ' ADD `qid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `id` int(11) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `weid` int(11) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `openid` varchar(120)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_quan_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_quan_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_quan_pinglun') . ' ADD `pid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `pic` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'sai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `sai` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'indexbg')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `indexbg` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'listbg')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `listbg` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'fengmian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `fengmian` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'topbg')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `topbg` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'listbgcolor')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `listbgcolor` varchar(30) NOT NULL  DEFAULT #ec3c05 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'listcolor')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `listcolor` varchar(30) NOT NULL  DEFAULT #ffffff COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'fx_title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `fx_title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'fx_tubiao')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `fx_tubiao` varchar(250)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'banquan_url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `banquan_url` varchar(250)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'banquan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `banquan` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'bg_color')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `bg_color` varchar(30) NOT NULL  DEFAULT #005192 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'bottom_color')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `bottom_color` varchar(30) NOT NULL  DEFAULT #feda0d COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'nr_color')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `nr_color` varchar(30) NOT NULL  DEFAULT #057ac9 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'paddtop')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `paddtop` int(10) NOT NULL  DEFAULT 400 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'size_color')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `size_color` varchar(30)   DEFAULT #ffffff COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_1` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_2` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_3')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_3` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_4')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_4` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_5')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_5` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_6')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_6` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_7')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_7` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_8')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_8` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai')) {
    if (!pdo_fieldexists('siyuan_cms_sai', 'baoming_tishi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai') . ' ADD `baoming_tishi` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_danye')) {
    if (!pdo_fieldexists('siyuan_cms_sai_danye', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_danye') . ' ADD `sid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `id` int(10) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `displayorder` tinyint(3) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `url` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'left')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `left` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'top')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `top` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_menu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_menu', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_menu') . ' ADD `sid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_news')) {
    if (!pdo_fieldexists('siyuan_cms_sai_news', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_news') . ' ADD `sid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `sid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `username` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_1` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_2` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_3')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_3` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_4')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_4` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_5')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_5` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_6')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_6` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_7')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_7` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_user')) {
    if (!pdo_fieldexists('siyuan_cms_sai_user', 'baoming_8')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_user') . ' ADD `baoming_8` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `sid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_sai_zanzhu')) {
    if (!pdo_fieldexists('siyuan_cms_sai_zanzhu', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_sai_zanzhu') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `weid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'qnsk')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `qnsk` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `name` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'city')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `city` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'ad')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `ad` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `tel` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'weixin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `weixin` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'zhuangxiu_xiaoxi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `zhuangxiu_xiaoxi` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'tougao_xiaoxi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `tougao_xiaoxi` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'color')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `color` varchar(50) NOT NULL  DEFAULT #fb9032 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'logo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `logo` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'qr')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `qr` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'qnscode')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `qnscode` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'qnym')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `qnym` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'qnak')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `qnak` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'apiclient_cert')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `apiclient_cert` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'apiclient_key')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `apiclient_key` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `video` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'tel_pay')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `tel_pay` decimal(10,2) NOT NULL  DEFAULT 0.00 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'xinxi_pay')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `xinxi_pay` decimal(10,2) NOT NULL  DEFAULT 0.00 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_setting')) {
    if (!pdo_fieldexists('siyuan_cms_setting', 'shop_pay')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_setting') . ' ADD `shop_pay` decimal(10,2) NOT NULL  DEFAULT 0.00 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'ordersn')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `ordersn` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `tel` varchar(32) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `address` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'longitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `longitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'latitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `latitude` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `fenxiang` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `video` varchar(2000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'biaoti')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `biaoti` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'ad')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `ad` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'zi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `zi` varchar(2) NOT NULL   COMMENT \'\';');
    }
}

if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `url` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'youhui')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `youhui` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `blei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `slei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'descimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `descimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `thumb` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `flash` varchar(250) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `yuedu` int(20) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `pinglun` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'yingye')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `yingye` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop')) {
    if (!pdo_fieldexists('siyuan_cms_shop', 'weixin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop') . ' ADD `weixin` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'所属帐号\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'nid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `nid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'关联导航id\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'分类名称\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'parentid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `parentid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'上级分类ID,0为第一级\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `displayorder` tinyint(3) unsigned NOT NULL  DEFAULT 0 COMMENT \'排序\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'enabled')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `enabled` tinyint(1) unsigned NOT NULL  DEFAULT 1 COMMENT \'是否开启\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_shop_fenlei', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_fenlei') . ' ADD `thumb` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_img')) {
    if (!pdo_fieldexists('siyuan_cms_shop_img', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_img') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_img')) {
    if (!pdo_fieldexists('siyuan_cms_shop_img', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_img') . ' ADD `pic` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_img')) {
    if (!pdo_fieldexists('siyuan_cms_shop_img', 'mid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_img') . ' ADD `mid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'shopid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `shopid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'key')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `key` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'value')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `value` varchar(512) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_kv')) {
    if (!pdo_fieldexists('siyuan_cms_shop_kv', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_kv') . ' ADD `displayorder` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'shopid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `shopid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `pid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_shop_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_shop_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_shop_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `tel` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'weixin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `weixin` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `address` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `blei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `slei` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'qr')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `qr` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'ordersn')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `ordersn` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel')) {
    if (!pdo_fieldexists('siyuan_cms_tel', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel') . ' ADD `openid` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'所属帐号\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'nid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `nid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'关联导航id\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'分类名称\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'parentid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `parentid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'上级分类ID,0为第一级\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `displayorder` tinyint(3) unsigned NOT NULL  DEFAULT 0 COMMENT \'排序\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'enabled')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `enabled` tinyint(1) unsigned NOT NULL  DEFAULT 1 COMMENT \'是否开启\';');
    }
}
if (pdo_tableexists('siyuan_cms_tel_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_tel_fenlei', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tel_fenlei') . ' ADD `thumb` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'weixin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `weixin` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `uid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `username` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao')) {
    if (!pdo_fieldexists('siyuan_cms_tougao', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao') . ' ADD `yuedu` int(10)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao_img')) {
    if (!pdo_fieldexists('siyuan_cms_tougao_img', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao_img') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao_img')) {
    if (!pdo_fieldexists('siyuan_cms_tougao_img', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao_img') . ' ADD `pic` varchar(500) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tougao_img')) {
    if (!pdo_fieldexists('siyuan_cms_tougao_img', 'mid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tougao_img') . ' ADD `mid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `title` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `thumb` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'fx_title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `fx_title` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'fx_tubiao')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `fx_tubiao` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'top_pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `top_pic` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'ka_pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `ka_pic` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'money')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `money` decimal(10,2)   DEFAULT 0.00 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `time` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `address` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'longitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `longitude` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'latitude')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `latitude` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan')) {
    if (!pdo_fieldexists('siyuan_cms_tuan', 'ka_pic_bottom')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan') . ' ADD `ka_pic_bottom` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `sid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_gongsi', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_gongsi') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `body` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `sid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_huodong')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_huodong', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_huodong') . ' ADD `url` varchar(255)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `thumb` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'sid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `sid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_tuan_pinpai')) {
    if (!pdo_fieldexists('siyuan_cms_tuan_pinpai', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_tuan_pinpai') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `blei` int(11)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `video` varchar(1000) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `url` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'缩略图1\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `fenxiang` varchar(1024) NOT NULL   COMMENT \'分享缩率图\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'laiyuan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `laiyuan` varchar(50) NOT NULL   COMMENT \'来源\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'zuozhe')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `zuozhe` varchar(50) NOT NULL   COMMENT \'作者\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `zan` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `cai` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'tuijian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `tuijian` int(2) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `flash` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `slei` int(11)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod')) {
    if (!pdo_fieldexists('siyuan_cms_vod', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `weid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'所属帐号\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'nid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `nid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'关联导航id\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'分类名称\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `thumb` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `status` int(1)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'parentid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `parentid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'上级分类ID,0为第一级\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `displayorder` tinyint(3) unsigned NOT NULL  DEFAULT 0 COMMENT \'排序\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_fenlei')) {
    if (!pdo_fieldexists('siyuan_cms_vod_fenlei', 'enabled')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_fenlei') . ' ADD `enabled` tinyint(1) unsigned NOT NULL  DEFAULT 1 COMMENT \'是否开启\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'newsid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `newsid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `uid` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `pid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_vod_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'recommendation')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `recommendation` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'video')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `video` varchar(600) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `fenxiang` varchar(1024) NOT NULL   COMMENT \'分享缩率图\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `zan` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'点赞数\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_vod_zhuanti')) {
    if (!pdo_fieldexists('siyuan_cms_vod_zhuanti', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_vod_zhuanti') . ' ADD `cai` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `pic` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `flash` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'zhuti')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `zhuti` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin')) {
    if (!pdo_fieldexists('siyuan_cms_weixin', 'weixin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin') . ' ADD `weixin` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `url` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `zan` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'点赞数\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'flash')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `flash` varchar(255) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'descimgs')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `descimgs` mediumtext    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `cai` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'weixinid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `weixinid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news', 'laiyuan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news') . ' ADD `laiyuan` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `avatar` varchar(300) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'uniacid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `uniacid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'newsid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `newsid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `name` varchar(64) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `content` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'pid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `pid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `status` tinyint(4) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_weixin_news_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_weixin_news_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_weixin_news_pinglun') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `uid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `blei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `slei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'chengse')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `chengse` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'leixing')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `leixing` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'biansu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `biansu` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'jiage')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `jiage` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_car')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_car', 'pinpai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_car') . ' ADD `pinpai` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `uid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `blei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `slei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'jiage')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `jiage` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'leixing')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `leixing` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_chongwu')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_chongwu', 'sex')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_chongwu') . ' ADD `sex` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `blei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `slei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'jiage')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `jiage` int(12) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_ershou')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_ershou', 'xinjiu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_ershou') . ' ADD `xinjiu` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'gongzuo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `gongzuo` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'qiye')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `qiye` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'renshu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `renshu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'zhiwei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `zhiwei` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'xueli')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `xueli` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'gongzi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `gongzi` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `uid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'blei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `blei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_geren')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_geren', 'slei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_geren') . ' ADD `slei` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `avatar` varchar(255)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `name` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'huxing')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `huxing` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'mianji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `mianji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'louceng_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `louceng_1` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'louceng_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `louceng_2` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'zhuangxiu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `zhuangxiu` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_house')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_house', 'jiage')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_house') . ' ADD `jiage` varchar(20) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_img')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_img', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_img') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_img')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_img', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_img') . ' ADD `pic` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_img')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_img', 'mid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_img') . ' ADD `mid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_img')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_img', 'type')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_img') . ' ADD `type` varchar(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'qiye')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `qiye` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'renshu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `renshu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'zhiwei')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `zhiwei` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'xueli')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `xueli` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'gongzuo')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `gongzuo` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'gongzi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `gongzi` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `avatar` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_job')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_job', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_job') . ' ADD `name` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'phone')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `phone` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `openid` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'ding')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `ding` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'end_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `end_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'ding_time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `ding_time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'huxing')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `huxing` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'mianji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `mianji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `yuedu` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'louceng_1')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `louceng_1` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'zhuangxiu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `zhuangxiu` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `title` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'louceng_2')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `louceng_2` varchar(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'jiage')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `jiage` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `name` varchar(20)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `avatar` varchar(255)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_xinxi_zufang')) {
    if (!pdo_fieldexists('siyuan_cms_xinxi_zufang', 'zujin')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_xinxi_zufang') . ' ADD `zujin` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `id` int(11) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `weid` int(11) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `title` varchar(320)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `thumb` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'zhiboid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `zhiboid` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'qiniu_tuiliu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `qiniu_tuiliu` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'qiniu_play')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `qiniu_play` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `uid` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'appkey')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `appkey` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'renshu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `renshu` int(11)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'lx')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `lx` int(1)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'zb_lx')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `zb_lx` int(1)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'starttime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `starttime` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'endtime')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `endtime` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'shua')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `shua` int(10) NOT NULL  DEFAULT 30 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'fenxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `fenxiang` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'zhibo_url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `zhibo_url` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'tuwen_url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `tuwen_url` varchar(300)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `zan` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'cai')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `cai` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo') . ' ADD `yuedu` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `weid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `openid` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `avatar` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `name` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `username` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `tel` varchar(20) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'state')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `state` int(2) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'uid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `uid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'zid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `zid` int(11) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_admin')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_admin', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_admin') . ' ADD `status` int(1) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `id` int(11) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `weid` int(11) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `username` varchar(64)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `avatar` varchar(250)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `time` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'zan')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `zan` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `openid` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `pic` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'vod')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `vod` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_body')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_body', 'zhiboid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_body') . ' ADD `zhiboid` int(10) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `id` int(11) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `weid` int(11) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `body` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'username')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `username` varchar(64)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'avatar')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `avatar` varchar(250)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `time` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhibo_pinglun')) {
    if (!pdo_fieldexists('siyuan_cms_zhibo_pinglun', 'zhiboid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhibo_pinglun') . ' ADD `zhiboid` int(11)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `tel` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `body` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'xiaoqu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `xiaoqu` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'mianji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `mianji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `time` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'gongsi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `gongsi` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_baojia')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_baojia', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_baojia') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_flash')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_flash', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_flash') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_flash')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_flash', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_flash') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_flash')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_flash', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_flash') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_flash')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_flash', 'url')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_flash') . ' ADD `url` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_flash')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_flash', 'attachment')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_flash') . ' ADD `attachment` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `pic` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `body` varchar(1000)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve', 'ad')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve') . ' ADD `ad` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'content')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `content` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'gonglveid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `gonglveid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gonglve_news')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gonglve_news', 'n_title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' ADD `n_title` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `name` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'pic')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `pic` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `body` text    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `displayorder` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'ad')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `ad` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `thumb` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'gongdi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `gongdi` int(10)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'anli')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `anli` int(10)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'yezhu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `yezhu` int(10)   DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'openid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `openid` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi', 'address')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' ADD `address` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'title')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `title` varchar(100) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `body` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'yuedu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `yuedu` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'阅读数\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'gongsiid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `gongsiid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'gongsi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `gongsi` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'sheji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `sheji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'huxing')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `huxing` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'shejiid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `shejiid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_anli')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_anli', 'xiaoqu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' ADD `xiaoqu` varchar(50)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `id` int(10) unsigned NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `weid` int(10) unsigned NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `body` text NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'thumb')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `thumb` varchar(1024) NOT NULL   COMMENT \'内容配图\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'displayorder')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `displayorder` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `time` int(10) unsigned NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'pinglun')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `pinglun` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'gongsiid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `gongsiid` int(10)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'touxiang')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `touxiang` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'gongsi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `gongsi` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_gongsi_sheji')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_gongsi_sheji', 'tedian')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' ADD `tedian` varchar(200)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `tel` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `body` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'xiaoqu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `xiaoqu` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'mianji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `mianji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `time` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'gongsi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `gongsi` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yanfang')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yanfang', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yanfang') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'id')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `id` int(11) NOT NULL auto_increment  COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'weid')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `weid` int(11) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'name')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `name` varchar(50) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'tel')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `tel` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'body')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `body` varchar(500)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'xiaoqu')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `xiaoqu` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'mianji')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `mianji` varchar(100)    COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'time')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `time` int(10) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'gongsi')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `gongsi` varchar(200) NOT NULL   COMMENT \'\';');
    }
}
if (pdo_tableexists('siyuan_cms_zhuangxiu_yuyue')) {
    if (!pdo_fieldexists('siyuan_cms_zhuangxiu_yuyue', 'status')) {
        pdo_query('ALTER TABLE ' . tablename('siyuan_cms_zhuangxiu_yuyue') . ' ADD `status` int(1) NOT NULL  DEFAULT 0 COMMENT \'\';');
    }
}