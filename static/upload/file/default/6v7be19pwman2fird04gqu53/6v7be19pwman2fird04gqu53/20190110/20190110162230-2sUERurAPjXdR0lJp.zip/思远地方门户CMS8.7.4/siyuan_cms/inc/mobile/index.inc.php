<?php

defined('IN_IA') or exit('Access Denied');

class Siyuan_Cms_doMobileIndex extends Siyuan_CmsModuleSite
{

    public function __construct()
    {
        parent::__construct();
    }

    public function exec()
    {
        global $_W, $_GPC;
        $do = 'index';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $index_set = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_index') . " WHERE weid = :weid ", array(
            ':weid' => $_W['uniacid']
        ));
        if ($index_set['ajax'] == '0') {
            $ajax = 'news';
            $ajax_db = 'siyuan_cms_news';
        } elseif ($index_set['ajax'] == '1')  {
            $ajax = 'weixin';
            $ajax_db = 'siyuan_cms_weixin_news';
        }elseif ($index_set['ajax'] == '2')  {
            $ajax = 'shop';
            $ajax_db = 'siyuan_cms_shop';
        }
        $psize = 10;
        if ($act == 'index') {
            $set = pdo_fetch("SELECT name,ad,logo,city,gz_open,gz_name,gz_ad,gz_btn,gz_logo,qr FROM " . tablename('siyuan_cms_setting') . " WHERE weid = :weid ", array(
                ':weid' => $_W['uniacid']
            ));
            $share = pdo_fetch("SELECT index_title,index_pic FROM " . tablename('siyuan_cms_share_set') . " WHERE weid = :weid ", array(
                ':weid' => $_W['uniacid']
            ));
            $title = $set['name'];
            $nav = pdo_fetchall("SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM " . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
            $index_nav = pdo_fetchall("SELECT displayorder,thumb,url,title FROM " . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC LIMIT 100");
            $flash = pdo_fetchall("SELECT id,url,thumb FROM " . tablename('siyuan_cms_index_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
            $city_list = pdo_fetchall("SELECT id,displayorder,thumb,title,url FROM " . tablename('siyuan_cms_city') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 16");
            $gonggao_list = pdo_fetchall("SELECT id,displayorder,title FROM " . tablename('siyuan_cms_gonggao') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC,id DESC LIMIT 10");
            $index_list = pdo_fetchall("SELECT displayorder,thumb,name,id,parentid,body FROM " . tablename('siyuan_cms_index_list') . " WHERE weid = '{$_W['weid']}' and parentid = 0 ORDER BY displayorder ASC LIMIT 4");
            foreach ($index_list as $re) {
                $mreply_list = pdo_fetchall("SELECT displayorder,thumb,url,name,id,parentid FROM " . tablename('siyuan_cms_index_list') . "WHERE weid = '{$_W['weid']}' and parentid = :parentid ORDER BY displayorder ASC LIMIT 16", array(
                    ':parentid' => $re['id']
                ));
                //var_dump($mreply_list);
                
                foreach ($mreply_list as $mre) {
                    $re['mreply_list'][$mre['id']]['url'] = $mre['url'];
                    $re['mreply_list'][$mre['id']]['name'] = $mre['name'];
                    $re['mreply_list'][$mre['id']]['id'] = $mre['id'];
                    $re['mreply_list'][$mre['id']]['thumb'] = $mre['thumb'];
                }
                $reply_list[] = $re;
                
            }
//             var_dump($reply_list);
//             var_dump($reply_list[0][mreply_list]);
//             var_dump($reply_list[1][mreply_list]);
//             var_dump($reply_list[2][mreply_list]);
//             exit();
            header('Content-Type:text/html;charset=utf-8');
            $api = pdo_fetch("SELECT hefeng_key,city FROM " . tablename('siyuan_cms_api') . " WHERE weid = :weid ", array(
                ':weid' => $_W['uniacid']
            ));
            $url = 'https://free-api.heweather.com/v5/weather?city=' . $api['city'] . '&key=' . $api['hefeng_key'];
            $res = file_get_contents($url);
            $res = json_decode($res, true);
            $weather_city = $res['HeWeather5'][0]['basic']['city'];
            $weather_weather = $res['HeWeather5'][0]['now']['cond']['txt'];
            $weather_temp = $res['HeWeather5'][0]['now']['tmp'];
            $weather_qr = $res['HeWeather5'][0]['now']['cond']['code'];
            $weather_pm = $res['HeWeather5'][0]['aqi']['city']['pm25'];
            $weather_pmdj = $res['HeWeather5'][0]['aqi']['city']['qlty'];
            $weather_feng = $res['HeWeather5'][0]['now']['wind']['dir'];
            $weather_fengli = $res['HeWeather5'][0]['now']['wind']['sc'];
            $weekarray = array(
                "日",
                "一",
                "二",
                "三",
                "四",
                "五",
                "六"
            );
            $weather_week = '星期' . $weekarray[date("w")];
            $weather_day = date("d");
            $weather_months = date("m");
            if($ajax=='shop'){
                $list_tj = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and status = '1' ORDER BY ding DESC ,displayorder DESC LIMIT 50");
                 
            }else{
                $list = pdo_fetchall('SELECT * FROM ' . tablename($ajax_db) . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC, id DESC LIMIT {$psize}");
                foreach ($list as $re) {
                    $re = array(
                        'id' => $re['id'],
                        'thumb' => $re['thumb'],
                        'title' => $re['title'],
                        'yuedu' => $re['yuedu'],
                        'pinglun' => $re['pinglun'],
                        'tuijian' => $re['tuijian'],
                        'wurl' => $re['wurl'],
                        'url' => $this->createMobileUrl($ajax, array(
                            'id' => $re['id'],
                            'act' => 'news'
                        )),
                        'descimgs' => unserialize($re['descimgs']),
                        'time' => date('m-d H:i', $re['time'])
                    );
                    $reply[] = $re;
                }
                $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename($ajax_db) . " WHERE weid = '{$_W['weid']}'");
                if ($total % $psize == 0) {
                    $total_page = $total / $psize;
                } else {
                    $total_page = floor($total / $psize) + 1;
                } 
            }
    
            include $this->template('index');
        }
        if ($act == 'list') {
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT * FROM ' . tablename($ajax_db) . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename($ajax_db) . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend ++;
                json_encode(array(
                    'status' => '200'
                ));
            } else {
                json_encode(array(
                    'status' => '100'
                ));
            }
            foreach ($list as $re) {
                $re = array(
                    'id' => $re['id'],
                    'thumb' =>$re['thumb'],
                    'title' => $re['title'],
                    'yuedu' => $re['yuedu'],
                    'wurl' => $re['wurl'],
                    'pinglun' => $re['pinglun'],
                    'tuijian' => $re['tuijian'],
                    'wurl' => $re['wurl'],
                    'url' => $this->createMobileUrl($ajax, array(
                        'id' => $re['id'],
                        'act' => 'news'
                    )),
                    'descimgs' => unserialize($re['descimgs']),
                    'time' => date('m-d H:i', $re['time'])
                );
                $reply[] = $re;
            }
            include $this->template('cms/index_list');
        }
    }
}
$obj = new Siyuan_Cms_doMobileIndex();
$obj->exec();