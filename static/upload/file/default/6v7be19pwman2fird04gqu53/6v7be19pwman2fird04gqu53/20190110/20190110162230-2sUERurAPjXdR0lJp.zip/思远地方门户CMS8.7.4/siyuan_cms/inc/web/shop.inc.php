<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebShop extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		$fenlei = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_shop_fenlei') . " WHERE weid = '{$_W['weid']}' ORDER BY parentid ASC, displayorder ASC, id ASC ", array(), 'id');
		if ($op == 'display') {
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= ' AND title LIKE :keyword';
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			$list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_shop') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/shop/shop');
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$pic = pdo_fetchall("SELECT pic FROM " . tablename('siyuan_cms_shop_img') . " WHERE mid = '{$id}' ORDER BY id DESC");
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_shop') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql);
			$pics_temp = unserialize($item['descimgs']);
			$pics = array();
			if ($pics_temp) {
				foreach ($pics_temp as $pic) {
					array_push($pics, tomedia($pic));
				}
				$item['descimgs'] = $pics;
			}
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_shop_kv') . ' WHERE `shopid` = ' . $id . ' ORDER BY displayorder ASC';
			$item['params'] = pdo_fetchAll($sql);
			if (!empty($fenlei)) {
				$children = '';
				foreach ($fenlei as $cid => $cate) {
					if (!empty($cate['parentid'])) {
						$children[$cate['parentid']][] = $cate;
					} else {
						$parent[$cate['id']] = $cate;
					}
				}
			}
			$blei = $item['blei'];
			$slei = $item['slei'];
			if (checksubmit('submit')) {
				if (empty($_GPC['name'])) {
					message('商家名称不能为空，请重新输入！');
				}
				$data = array('pic'=>$_GPC['pic'],'weid' => $_W['uniacid'], 'name' => $_GPC['name'], 'blei' => intval($_GPC['fenlei']['parentid']), 'slei' => intval($_GPC['fenlei']['childid']), 'thumb' => $_GPC['thumb'], 'color' => $_GPC['color'], 'flash' => $_GPC['flash'], 'zi' => $_GPC['zi'], 'tel' => $_GPC['tel'], 'status' => 1, 'ad' => $_GPC['ad'], 'url' => $_GPC['url'], 'address' => $_GPC['address'], 'yingye' => $_GPC['yingye'], 'youhui' => $_GPC['youhui'], 'body' => htmlspecialchars_decode($_GPC['body']), 'fenxiang' => $_GPC['fenxiang'], 'video' => htmlspecialchars_decode($_GPC['video']), 'biaoti' => $_GPC['biaoti'], 'displayorder' => $_GPC['displayorder']);
				$picpath = $_GPC['descimgs'];
				if (is_array($picpath) && !empty($picpath)) {
					$paths = array();
					foreach ($picpath as $p) {
						array_push($paths, $p[0]);
					}
					$data['descimgs'] = serialize($paths);
				}
				$geo = $_GPC['geo'];
				if (is_array($geo) && !empty($geo)) {
					$data['longitude'] = $geo['lng'];
					$data['latitude'] = $geo['lat'];
				}
				$shop_id = $id;
				if (empty($id)) {
					pdo_insert('siyuan_cms_shop', $data);
					$shop_id = pdo_insertid();
				} else {
					unset($data['createtime']);
					pdo_update('siyuan_cms_shop', $data, array('id' => $id));
				}
				$ids = array();
				if (isset($_GPC['params_key']) && $_GPC['params_key']) {
					foreach ($_GPC['params_key'] as $k => $v) {
						$data = array('weid' => $_W['uniacid'], 'shopid' => $shop_id, 'key' => $_GPC['params_key'][$k], 'value' => $_GPC['params_value'][$k], 'displayorder' => $k);
						if (empty($_GPC['params_id'][$k])) {
							pdo_insert('siyuan_cms_shop_kv', $data);
							$ids[] = pdo_insertid();
						} else {
							pdo_update('siyuan_cms_shop_kv', $data, array('id' => $_GPC['params_id'][$k]));
							$ids[] = $_GPC['params_id'][$k];
						}
					}
				}
				$sql = 'DELETE FROM ' . tablename('siyuan_cms_shop_kv') . ' WHERE shopid=:shopid';
				if (!empty($ids)) {
					$sql .= ' AND id NOT IN(' . implode(',', $ids) . ')';
					pdo_query($sql, array(':shopid' => $shop_id));
				} else {
					pdo_query($sql, array(':shopid' => $shop_id));
				}
				$path = IA_ROOT . '/addons/siyuan_cms/code/shop/';
				if (!is_dir($path)) {
					load()->func('file');
					mkdirs($path);
				}
				$file = $path . "shop_" . $shop_id . '.png';
				require_once IA_ROOT . '/framework/library/qrcode/phpqrcode.php';
				$chl = "BEGIN:VCARD\nVERSION:3.0" . "\nFN:" . $_GPC['name'] . "\nTEL:" . $_GPC['tel'] . "\nADR;WORK;POSTAL:" . $_GPC['address'] . "\nEND:VCARD";
				QRcode::png($chl, $file, QR_ECLEVEL_Q, 10);
				message('商家更新成功！', url('site/entry/shop', array('op' => 'display', 'id' => $shop_id, 'm' => 'siyuan_cms')), 'success');
			}
			include $this->template('web/shop/shop');
			die;
		} elseif ($op == 'params') {
			global $_W, $_GPC;
			include $this->template('web/shop/shop-params-new');
			die;
		} elseif ($op == 'deletekv') {
			$id = intval($_GPC['id']);
			if ($id > 0) {
				pdo_delete('siyuan_cms_shop_kv', array('id' => $id));
			}
			echo 'success';
		} else {
			if ($op == 'zhiding') {
				$id = intval($_GPC['id']);
				$sql = "SELECT * FROM " . tablename('siyuan_cms_shop') . ' WHERE `id` = ' . $id;
				$item = pdo_fetch($sql, array());
				if (empty($item)) {
					message('抱歉，信息不存在或是已经被删除！');
				}
				pdo_update('siyuan_cms_shop', array('id' => $id, 'ding' => 1), array('id' => $id));
				message('置顶成功！', referer(), 'success');
				die;
			} else {
				if ($op == 'quxiao') {
					$id = intval($_GPC['id']);
					$sql = "SELECT * FROM " . tablename('siyuan_cms_shop') . ' WHERE `id` = ' . $id;
					$item = pdo_fetch($sql, array());
					if (empty($item)) {
						message('抱歉，信息不存在或是已经被删除！');
					}
					pdo_update('siyuan_cms_shop', array('id' => $id, 'ding' => 0), array('id' => $id));
					message('取消置顶！', referer(), 'success');
					die;
				} else {
					if ($op == 'delete') {
						$id = intval($_GPC['id']);
						$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_shop') . " WHERE id = :id", array(':id' => $id));
						if (empty($row)) {
							message('抱歉，信息不存在或是已经被删除！');
						}
						pdo_delete('siyuan_cms_shop', array('id' => $id));
						message('删除成功！', referer(), 'success');
						die;
					}
				}
			}
		}
	}
}
$obj = new Siyuan_Cms_doWebShop();
$obj->exec();