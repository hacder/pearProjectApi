<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebSet extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_W, $_GPC;
		$weid = $_W['uniacid'];
		$set = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_setting') . " WHERE weid = :weid ", array(':weid' => $_W['uniacid']));
		if (checksubmit('submit')) {
			$data = array('weid' => $_W['uniacid'], 'name' => $_GPC['name'], 'city' => $_GPC['city'], 'logo' => $_GPC['logo'], 'qr' => $_GPC['qr'], 'video' => $_GPC['video'], 'openid' => $_GPC['openid'], 'zhuangxiu_xiaoxi' => $_GPC['zhuangxiu_xiaoxi'], 'tougao_xiaoxi' => $_GPC['tougao_xiaoxi'], 'weixin' => $_GPC['weixin'], 'tel' => $_GPC['tel'], 'ad' => $_GPC['ad'], 'color' => $_GPC['color'], 'tel' => $_GPC['tel'], 'qnsk' => $_GPC['qnsk'], 'gz_open' => $_GPC['gz_open'], 'gz_name' => $_GPC['gz_name'], 'gz_ad' => $_GPC['gz_ad'], 'gz_btn' => $_GPC['gz_btn'], 'gz_logo' => $_GPC['gz_logo'], 'qnscode' => $_GPC['qnscode'], 'qnym' => $_GPC['qnym'], 'qnak' => $_GPC['qnak']);
			if (!empty($set)) {
				pdo_update('siyuan_cms_setting', $data, array('id' => $set['id']));
			} else {
				pdo_insert('siyuan_cms_setting', $data);
			}
			message('更新系统设置成功！', 'refresh');
		}
		include $this->template('web/cms/set');
	}
}
$obj = new Siyuan_Cms_doWebSet();
$obj->exec();