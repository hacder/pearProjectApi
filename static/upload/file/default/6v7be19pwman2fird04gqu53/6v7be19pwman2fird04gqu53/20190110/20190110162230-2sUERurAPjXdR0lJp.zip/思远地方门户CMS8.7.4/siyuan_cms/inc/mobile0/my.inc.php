<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileMy extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $do = 'my';
        $this->Checkeduseragent();
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $title = '个人中心';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $userinfo = mc_oauth_userinfo();
        $openid = $_W['fans']['from_user'];
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'index') {
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            $member = pdo_fetch('SELECT * FROM ' . tablename('mc_mapping_fans') . ' mapp left join ' . tablename('mc_members') . ' mem on mapp.uid = mem.uid  WHERE mapp.openid = \'' . $openid . '\'');
        }
        if ($act == 'tougao') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tougao') . " WHERE openid = '{$openid}' and uniacid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'tel') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tel') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'tougao_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_tougao', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'tel_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_tel', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'house') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_house') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'house_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_house', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'qiuzhi') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'qiuzhi_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_geren', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'job') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_job') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'job_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_job', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'zufang') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_zufang') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'zufang_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_zufang', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'car') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_car') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'car_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_car', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'ershou') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_ershou') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'ershou_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_ershou', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        if ($act == 'chongwu') {
            $openid = $_GPC['openid'];
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_chongwu') . " WHERE openid = '{$openid}' and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 30");
        }
        if ($act == 'chongwu_del') {
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_xinxi_chongwu', array('id' => $id));
            message('', $this->createMobileUrl('my'), 'success');
        }
        include $this->template('my/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileMy();
$obj->exec();