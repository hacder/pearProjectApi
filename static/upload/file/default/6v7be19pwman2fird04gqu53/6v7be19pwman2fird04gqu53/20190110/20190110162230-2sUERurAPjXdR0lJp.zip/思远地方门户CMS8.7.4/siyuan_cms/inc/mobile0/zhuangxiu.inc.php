<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhuangxiu extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $title = '&#x88C5;&#x4FEE;&#x9891;&#x9053;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,zhuangxiu_xiaoxi,tel FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_zhuangxiu_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'index') {
            $gongsi = pdo_fetchall('SELECT id,name,pic,ad,thumb FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT 2");
            $sheji = pdo_fetchall('SELECT id,name,touxiang FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT 16");
            $xuetang = pdo_fetchall('SELECT id,title,thumb,yuedu,time FROM ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT 8");
            $anli = pdo_fetchall('SELECT id,title,thumb,time,xiaoqu FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT 8");
            $data = array('weid' => $_W['weid'], 'name' => $_GPC['name'], 'xiaoqu' => $_GPC['xiaoqu'], 'tel' => $_GPC['tel'], 'mianji' => $_GPC['mianji'], 'gongsi' => $_GPC['gongsi'], 'body' => $_GPC['body'], 'status' => 0, 'time' => TIMESTAMP);
            if ($_W['ispost']) {
                if (empty($_GPC['id'])) {
                    pdo_insert('siyuan_cms_zhuangxiu_yuyue', $data);
                    $openid = pdo_fetch('SELECT name,openid FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi') . " WHERE name = '{$_GPC['gongsi']}'");
                    if ($_W['account']['level'] == 4) {
                        $data = array('touser' => $openid['openid'], 'template_id' => $set['zhuangxiu_xiaoxi'], 'url' => '', 'topcolor' => '#FF0000');
                        $data['data'] = array('first' => array('value' => '【' . $_GPC['gongsi'] . '】有新的预约'), 'keyword1' => array('value' => $_GPC['name'], 'color' => '#173177'), 'keyword2' => array('value' => '预约免费装修设计', 'color' => '#173177'), 'keyword3' => array('value' => $_GPC['tel'], 'color' => '#173177'), 'remark' => array('value' => '请尽快处理！'));
                        $token = $this->getToken();
                        $this->sendMBXX($token, $data);
                    }
                    message('发布成功，请等待我们的工作人员与您联系！', $this->createMobileUrl('zhuangxiu'), 'success');
                }
            }
        }
        include $this->template('zhuangxiu/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhuangxiu();
$obj->exec();