<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobilePk extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '&#35805;&#39064;';
        $act = $_GPC['act'] ? $_GPC['act'] : 'list';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        if (!in_array($act, array('list', 'news', 'red', 'blue', 'form_pinglun', 'ztzan', 'ajax', 'pinglun'))) {
            message('非法请求！(' . $act . ')');
        }
        if ($act == 'news') {
            $userinfo = mc_oauth_userinfo();
            $id = intval($_GPC['id']);
            $openid = $_W['openid'];
            $news = pdo_fetch('SELECT id,title,time,yuedu,pinglun,red,blue,body,fenxiang,red_guandian,blue_guandian,url FROM ' . tablename('siyuan_cms_pk') . ' WHERE `id` = ' . $id);
            $user = pdo_fetch('SELECT weid,openid,newsid FROM ' . tablename('siyuan_cms_pk_user') . " WHERE weid ={$_W['weid']} and newsid = {$news['id']}");
            $renshu = $news['red'] + $news['blue'];
            pdo_update('siyuan_cms_pk', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $this->Checkeduseragent();
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            $news = pdo_fetch('SELECT id,title,pinglun FROM ' . tablename('siyuan_cms_pk') . ' WHERE `id` = ' . $id);
            if (checksubmit('submit')) {
                $data = array('weid' => $_W['weid'], 'newsid' => $_GPC['newsid'], 'content' => $_GPC['content'], 'avatar' => $userinfo['avatar'], 'name' => $userinfo['nickname'], 'status' => 2, 'time' => TIMESTAMP);
                pdo_insert('siyuan_cms_pk_pinglun', $data);
                $new_id = pdo_insertid();
                if ($new_id) {
                    pdo_update('siyuan_cms_pk', array('pinglun' => $news['pinglun'] + 1), array('id' => $news['id']));
                    message('', $this->createMobileUrl('pk', array('act' => 'news', 'id' => $id)), 'success');
                } else {
                    message('系统错误，请稍后重试', referer(), 'error');
                }
            }
        }
        if ($act == 'pinglun') {
            global $_GPC, $_W;
            $id = intval($_GPC['id']);
            $page = intval($_GET['page']);
            $pagenum = 10;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT id,newsid,avatar,name,content,time FROM ' . tablename('siyuan_cms_pk_pinglun') . " WHERE newsid = {$id} and status = 2 ORDER BY id DESC LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    if (empty($item['avatar'])) {
                        $avatar = $_W['siteroot'] . 'addons/siyuan_cms/img/niming.jpg';
                        $name = '匿名网友';
                    } else {
                        $avatar = $item['avatar'];
                        $name = $item['name'];
                    }
                    $arr[] = array('avatar' => $avatar, 'name' => $name, 'content' => $item['content'], 'time' => date('m-d H:i', $item['time']));
                }
            }
            echo json_encode($arr);
        }
        if ($act == 'list') {
        }
        if ($act == 'ajax') {
            global $_GPC, $_W;
            $page = intval($_GET['page']);
            $pagenum = 5;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT id,thumb,title,yuedu,pinglun,time FROM ' . tablename('siyuan_cms_pk') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    $ajaxarr[] = array('url' => $this->createMobileUrl('pk', array('id' => $item['id'], 'act' => 'news')), 'thumb' => $_W['attachurl'] . $item['thumb'], 'title' => $item['title'], 'yuedu' => $item['yuedu'], 'pinglun' => $item['pinglun'], 'time' => date('m-d H:i', $item['time']));
                }
            }
            echo json_encode($ajaxarr);
        }
        if ($act == 'red') {
            $id = $_GPC['id'];
            $red = pdo_fetch('SELECT id,red FROM ' . tablename('siyuan_cms_pk') . " WHERE id = {$id}");
            $data = array('weid' => $_W['weid'], 'newsid' => $red['id'], 'openid' => $_W['openid']);
            pdo_insert('siyuan_cms_pk_user', $data);
            pdo_update('siyuan_cms_pk', array('red' => $red['red'] + 1), array('id' => $id));
            message('', referer(), 'success');
        }
        if ($act == 'blue') {
            $id = $_GPC['id'];
            $blue = pdo_fetch('SELECT id,blue FROM ' . tablename('siyuan_cms_pk') . " WHERE id = {$id}");
            $data = array('weid' => $_W['weid'], 'newsid' => $blue['id'], 'openid' => $_W['openid']);
            pdo_insert('siyuan_cms_pk_user', $data);
            pdo_update('siyuan_cms_pk', array('blue' => $blue['blue'] + 1), array('id' => $id));
            message('', $this->createMobileUrl('pk', array('act' => 'news', 'id' => $blue['id'])), 'success');
        }
        include $this->template('pk/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobilePk();
$obj->exec();