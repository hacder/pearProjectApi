<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebXinxi_Car extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_W, $_GPC;
		load()->func('tpl');
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($op == 'display') {
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= " AND title LIKE :keyword";
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			$list = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_xinxi_car') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_xinxi_car') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$parent = array();
			$children = array();
			if (!empty($fenlei)) {
				$children = '';
				foreach ($fenlei as $cid => $cate) {
					if (!empty($cate['parentid'])) {
						$children[$cate['parentid']][] = $cate;
					} else {
						$parent[$cate['id']] = $cate;
					}
				}
			}
			if (!empty($id)) {
				$item = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_xinxi_car') . " WHERE id = :id", array(':id' => $id));
				$photos = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_xinxi_img') . " WHERE type = 'car' and mid = {$id}");
				if (empty($item)) {
					message('抱歉，文章不存在或是已经删除！', '', 'error');
				}
			}
			if (checksubmit('submit')) {
				if (strstr($_GPC['pic'], 'http://')) {
					$xinxi_pic = $item['pic'];
				} else {
					$xinxi_pic = $_W['attachurl'] . $_GPC['pic'];
				}
				$data = array('weid' => $_W['weid'], 'title' => $_GPC['title'],'mleixing'=>$_GPC['mleixing'], 'name' => $_GPC['name'], 'phone' => $_GPC['phone'], 'jiage' => $_GPC['jiage'], 'pic' => $xinxi_pic, 'leixing' => $_GPC['leixing'], 'chengse' => $_GPC['chengse'], 'biansu' => $_GPC['biansu'], 'body' => $_GPC['body'], 'time' => TIMESTAMP);
				if (!empty($id)) {
					pdo_update('siyuan_cms_xinxi_car', $data, array('id' => $id));
				} else {
					pdo_insert('siyuan_cms_xinxi_car', $data);
					$id = pdo_insertid();
				}
				message('', $this->createWebUrl('xinxi_car', array('op' => 'display')), 'success');
			}
		} elseif ($op == 'img') {
			$id = intval($_GPC['id']);
			$photos = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_xinxi_img') . " WHERE type = 'car' and mid = {$id}");
			if (checksubmit('submit')) {
				if (!empty($_GPC['attachment-new'])) {
					foreach ($_GPC['attachment-new'] as $index => $row) {
						if (empty($row)) {
							continue;
						}
						$data = array('mid' => $id, 'type' => 'car', 'pic' => $_W['attachurl'] . $_GPC['attachment-new'][$index]);
						pdo_insert('siyuan_cms_xinxi_img', $data);
					}
				}
				if (!empty($_GPC['attachment'])) {
					foreach ($_GPC['attachment'] as $index => $row) {
						if (empty($row)) {
							continue;
						}
						$data = array('mid' => $id, 'type' => 'car', 'pic' => $_GPC['attachment'][$index]);
						pdo_update('siyuan_cms_xinxi_img', $data, array('id' => $index));
					}
				}
				message('', $this->createWebUrl('xinxi_car', array('op' => 'img', 'id' => $id)), 'success');
			}
		} elseif ($op == 'ding') {
			$id = intval($_GPC['id']);
			$status = intval($_GPC['status']);
			pdo_update('siyuan_cms_xinxi_car', array('ding' => $status), array('id' => $id));
			message('', referer(), 'success');
		} elseif ($op == 'del_img') {
			$id = intval($_GPC['id']);
			pdo_delete('siyuan_cms_xinxi_img', array('id' => $id));
			message('', referer(), 'success');
		} elseif ($op == 'delete') {
			$id = intval($_GPC['id']);
			$adv = pdo_fetch("SELECT id  FROM " . tablename('siyuan_cms_xinxi_car') . " WHERE id = '{$id}' AND weid=" . $_W['uniacid'] . "");
			if (empty($adv)) {
				message('抱歉，信息不存在或是已经被删除！', $this->createWebUrl('car', array('op' => 'display')), 'error');
			}
			pdo_delete('siyuan_cms_xinxi_car', array('id' => $id));
			message('', $this->createWebUrl('xinxi_car', array('op' => 'display')), 'success');
		} else {
			message('请求方式不存在');
		}
		include $this->template('web/xinxi/car');
	}
}
$obj = new Siyuan_Cms_doWebXinxi_Car();
$obj->exec();