<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhibo extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '直播';
        $do = 'zhibo';
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,video FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $psize = 10;
        $now = time();
        if ($act == 'index') {
            $list = pdo_fetchall('SELECT id,displayorder,title,starttime,endtime,yuedu,thumb FROM ' . tablename('siyuan_cms_zhibo') . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_zhibo') . " WHERE weid = '{$_W['weid']}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('zhibo/index');
        }
        if ($act == 'list') {
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,displayorder,title,starttime,endtime,yuedu,thumb FROM ' . tablename('siyuan_cms_zhibo') . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_zhibo') . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('zhibo/list');
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT id,title,fenxiang,body,zhiboid,zhibo_url,thumb,lx,zb_lx,yuedu FROM ' . tablename('siyuan_cms_zhibo') . ' WHERE `id` = ' . $id);
            $title = $news['title'];
            if ($news['zb_lx'] == '0') {
                $user_list = pdo_fetchall('SELECT id,zid,username,avatar FROM ' . tablename('siyuan_cms_zhibo_admin') . " WHERE weid = '{$_W['weid']}' and zid = {$id} and status = '1' ORDER BY id DESC LIMIT 20");
                include $this->template('zhibo/news');
            } else {
                include $this->template('zhibo/tuwen');
            }
        }
        if ($act == 'play') {
            $id = $_GPC['id'];
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_zhibo') . ' WHERE `id` = ' . $id);
            include $this->template('zhibo/play');
        }
        if ($act == 'pinglun') {
            $id = intval($_GPC['id']);
            $news = pdo_fetch('SELECT id,yuedu,shua FROM ' . tablename('siyuan_cms_zhibo') . ' WHERE `id` = ' . $id);
            $pinglun_list = pdo_fetchall('SELECT id,avatar,username,body,zhiboid FROM ' . tablename('siyuan_cms_zhibo_body') . " WHERE weid = '{$_W['weid']}' and zhiboid = {$id} ORDER BY id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_zhibo_body') . " WHERE weid = '{$_W['weid']}' and zhiboid = '{$id}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            pdo_update('siyuan_cms_zhibo', array('yuedu' => $news['yuedu'] + 1), array('id' => $id));
            include $this->template('zhibo/pinglun');
        }
        if ($act == 'admin') {
            $this->Checkeduseragent();
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_zhibo') . ' WHERE `id` = ' . $id);
            $user = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_zhibo_admin') . " WHERE openid = :openid and zid = {$news['id']}", array(':openid' => $openid));
            if ($_GPC['name']) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['name'] = $_GPC['name'];
                $data['tel'] = $_GPC['tel'];
                $data['username'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['zid'] = $news['id'];
                $data['avatar'] = $userinfo['avatar'];
                $data['status'] = 0;
                pdo_insert('siyuan_cms_zhibo_admin', $data);
                die(json_encode(array('status' => 1)));
            }
            include $this->template('zhibo/admin');
        }
        if ($act == 'vod_pinglun_list') {
            $zhiboid = intval($_GPC['zhiboid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,avatar,username,body,zhiboid FROM ' . tablename('siyuan_cms_zhibo_body') . " WHERE  weid = '{$_W['weid']}' and zhiboid = '{$zhiboid}' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_zhibo_body') . " WHERE weid = '{$_W['weid']}' and zhiboid = '{$zhiboid}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('zhibo/vod_pinglun_list');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $pid = intval($_GPC['pid']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $body = $_GPC['body'];
            if ($body) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['zhiboid'] = $id;
                $data['username'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_zhibo_body', $data);
            }
            die(json_encode(array('status' => 1)));
        }
    }
}
$obj = new Siyuan_Cms_doMobileZhibo();
$obj->exec();