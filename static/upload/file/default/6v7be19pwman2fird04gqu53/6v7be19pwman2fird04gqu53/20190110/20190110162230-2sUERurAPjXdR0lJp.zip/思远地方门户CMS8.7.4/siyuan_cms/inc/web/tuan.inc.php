<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebTuan extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($op == 'display') {
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= ' AND name LIKE :keyword';
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			$list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tuan') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_tuan') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/tuan/tuan');
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_tuan') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql);
			if (checksubmit('submit')) {
				$data = array('weid' => $_W['weid'], 'title' => $_GPC['title'], 'thumb' => $_GPC['thumb'], 'fx_title' => $_GPC['fx_title'], 'fx_tubiao' => $_GPC['fx_tubiao'], 'top_pic' => $_GPC['top_pic'], 'ka_pic' => $_GPC['ka_pic'], 'ka_pic_bottom' => $_GPC['ka_pic_bottom'], 'money' => $_GPC['money'], 'time' => $_GPC['time'], 'address' => $_GPC['address'], 'body' => htmlspecialchars_decode($_GPC['body']));
				$geo = $_GPC['geo'];
				if (is_array($geo) && !empty($geo)) {
					$data['longitude'] = $geo['lng'];
					$data['latitude'] = $geo['lat'];
				}
				if (empty($id)) {
					pdo_insert('siyuan_cms_tuan', $data);
				} else {
					pdo_update('siyuan_cms_tuan', $data, array('id' => $id));
				}
				message('更新成功！', url('site/entry/tuan', array('op' => 'display', 'm' => 'siyuan_cms', 'id' => $id)), 'success');
			}
			include $this->template('web/tuan/tuan');
			die;
		} else {
			if ($op == 'delete') {
				$id = intval($_GPC['id']);
				$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_tuan') . " WHERE id = :id", array(':id' => $id));
				if (empty($row)) {
					message('抱歉，文章不存在或是已经被删除！');
				}
				pdo_delete('siyuan_cms_tuan', array('id' => $id));
				message('删除成功！', referer(), 'success');
				die;
			}
		}
	}
}
$obj = new Siyuan_Cms_doWebTuan();
$obj->exec();