<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileHuodong extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '精彩活动';
        $do = 'huodong';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $huodong_fenlei = pdo_fetchall('SELECT id,name,displayorder FROM ' . tablename('siyuan_cms_huodong_fenlei') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC ,id DESC LIMIT 20");
        $psize = 10;
        $now = time();
        if ($act == 'index') {
            $bid = intval($_GPC['bid']);
            if (!empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $huodong_flash = pdo_fetchall('SELECT id,flash,thumb FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['uniacid']}' and flash = '1' ORDER BY id DESC LIMIT 5");
            $list = pdo_fetchall('SELECT id,displayorder,name,time,address,thumb,bm_time,endtime,open FROM ' . tablename('siyuan_cms_huodong') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['weid']}' {$condition}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('huodong/index');
        }
        if ($act == 'list') {
            $bid = intval($_GPC['bid']);
            if (!empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,displayorder,name,time,address,thumb,bm_time,endtime,open FROM ' . tablename('siyuan_cms_huodong') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['weid']}' {$condition}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('huodong/list');
        }
        if ($act == 'pinglun_list') {
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $huodongid = intval($_GPC['huodongid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_huodong_pinglun') . " WHERE  uniacid = '{$_W['weid']}'  and huodongid = '{$huodongid}' and pid = '0' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong_pinglun') . " WHERE uniacid = '{$_W['weid']}' and huodongid = '{$huodongid}' and pid = '0'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_huodong_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            include $this->template('huodong/pinglun_list');
        }
        if ($act == 'user_list') {
            $huodongid = intval($_GPC['huodongid']);
            $news = pdo_fetch('SELECT id,name,yuedu,time,time,endtime,bm_time,pinglun,thumb,blei,body,fenxiang,pic,biaoti,xianzhi,open,feiyong,address,lx FROM ' . tablename('siyuan_cms_huodong') . ' WHERE `id` = ' . $huodongid);
            $pindex = max(intval($_GPC['user_currentpage']), intval($_GPC['page']));
            $user_list = pdo_fetchall('SELECT avatar,username,status,body,huodongid FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE  weid = '{$_W['weid']}'  and huodongid = '{$huodongid}' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE weid = '{$_W['weid']}' and huodongid = '{$huodongid}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('huodong/user_list');
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT id,name,yuedu,time,time,endtime,bm_time,pinglun,thumb,blei,body,fenxiang,pic,biaoti,xianzhi,open,feiyong,address,lx,biaoti FROM ' . tablename('siyuan_cms_huodong') . ' WHERE `id` = ' . $id);
            $title = $news['name'];
            $news['kvs'] = pdo_fetchAll('SELECT * FROM ' . tablename('siyuan_cms_huodong_kv') . ' WHERE `huodongid` = ' . $id . ' ORDER BY displayorder ASC');
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $tongguo = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE huodongid = {$news['id']} and status = '1'");
            $shengyu = $news['xianzhi'] - $tongguo;
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_huodong_pinglun') . " WHERE uniacid = '{$_W['weid']}' and pid = '0' and huodongid = {$id} ORDER BY id DESC LIMIT {$psize}");
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_huodong_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong_pinglun') . " WHERE uniacid = '{$_W['weid']}' and huodongid = '{$id}' and pid = '0'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            $user_list = pdo_fetchall('SELECT avatar,username,status,body FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE weid = '{$_W['weid']}' and huodongid = {$news['id']} ORDER BY id DESC LIMIT {$psize}");
            $user_total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE weid = '{$_W['weid']}' and huodongid = '{$id}'");
            if ($user_total % $psize == 0) {
                $user_total_page = $user_total / $psize;
            } else {
                $user_total_page = floor($user_total / $psize) + 1;
            }
            pdo_update('siyuan_cms_huodong', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
            include $this->template('huodong/news');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $pid = intval($_GPC['pid']);
            $num = intval($_GPC['num']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $content = $_GPC['content'];
            if ($content) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['huodongid'] = $id;
                $data['pid'] = $pid;
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['content'] = $_GPC['content'];
                $data['status'] = 1;
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_huodong_pinglun', $data);
                pdo_update('siyuan_cms_huodong', array('pinglun' => $num + 1), array('id' => $id));
            }
            die(json_encode(array('status' => 1)));
        }
        if ($act == 'baoming') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_huodong') . ' WHERE `id` = ' . $id);
            $user_ok = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_huodong_users') . " WHERE openid = :openid and huodongid = {$id}", array(':openid' => $openid));
            if ($user_ok['status'] == '0' and $news['feiyong'] > '0') {
                $dingdan = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_order') . " WHERE `ordersn` = {$user_ok['ordersn']}");
            }
            if ($news['feiyong'] > '0') {
                $ordersn = date('ymd') . random(10, 1);
                if ($_GPC['name']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['name'] = $_GPC['name'];
                    $data['tel'] = $_GPC['tel'];
                    $data['body'] = $_GPC['body'];
                    $data['username'] = $userinfo['nickname'];
                    $data['openid'] = $openid;
                    $data['huodongid'] = $news['id'];
                    $data['ordersn'] = $ordersn;
                    $data['avatar'] = $userinfo['avatar'];
                    $data['status'] = 0;
                    $data['time'] = TIMESTAMP;
                    pdo_insert('siyuan_cms_huodong_users', $data);
                    $pay = array('weid' => $_W['uniacid'], 'from_user' => $openid, 'price' => $news['feiyong'], 'title' => $news['name'], 'remark' => $_GPC['name'] . $_GPC['tel'], 'status' => 0, 'type' => 'huodong', 'ordersn' => $ordersn, 'createtime' => time());
                    pdo_insert('siyuan_cms_order', $pay);
                    $orderid = pdo_insertid();
                    die(json_encode(array('status' => 1, 'id' => $orderid)));
                }
            } else {
                if ($_GPC['name']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['name'] = $_GPC['name'];
                    $data['tel'] = $_GPC['tel'];
                    $data['openid'] = $openid;
                    $data['body'] = $_GPC['body'];
                    $data['avatar'] = $userinfo['avatar'];
                    $data['huodongid'] = $news['id'];
                    $data['ordersn'] = $ordersn;
                    $data['status'] = 0;
                    $data['username'] = $userinfo['nickname'];
                    $data['time'] = TIMESTAMP;
                    pdo_insert('siyuan_cms_huodong_users', $data);
                    die(json_encode(array('status' => 2)));
                }
            }
            include $this->template('huodong/baoming');
        }
    }
}
$obj = new Siyuan_Cms_doMobileHuodong();
$obj->exec();