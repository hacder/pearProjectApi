<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebPk extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($op == 'display') {
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= " AND title LIKE :keyword";
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			if (!empty($_GPC['cate_1'])) {
				$cid = intval($_GPC['cate_1']);
				$condition .= " AND blei = '{$cid}'";
			}
			$list = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_pk') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_pk') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/news/pk');
		} elseif ($op == 'pinglun') {
			$pageNumber = max(1, intval($_GPC['page']));
			$pageSize = 50;
			$status = $_GPC['status'];
			if (!$status) {
				$status = '2';
			}
			$sql = "SELECT * FROM " . tablename('siyuan_cms_pk_pinglun') . " WHERE status = '" . $status . "'  and   weid = '" . $_W['weid'] . "' order by id desc";
			$sql2 = 'SELECT COUNT(*) FROM ' . tablename('siyuan_cms_pk_pinglun') . " WHERE status = '" . $status . "'  and weid = '" . $_W['weid'] . "' ORDER BY id DESC";
			$list = pdo_fetchall($sql);
			$total = pdo_fetchcolumn($sql2);
			$pager = pagination($total, $pageNumber, $pageSize);
			include $this->template('web/news/pk_pinglun');
		} else {
			if ($op == 'update') {
				$id = intval($_GPC['id']);
				$admin = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_pk_pinglun') . " WHERE id = " . $id);
				if (empty($admin)) {
					message('抱歉，信息不存在或是已经被删除！');
				}
				pdo_update('siyuan_cms_pk_pinglun', array('status' => 2), array('id' => $id));
				message('审核成功！', referer(), 'success');
			} elseif ($op == 'pk_delete') {
				$id = intval($_GPC['id']);
				if (pdo_delete('siyuan_cms_pk_pinglun', array('id' => $id))) {
					message('删除成功', $this->createWebUrl('pk', array('op' => 'pinglun')), 'success');
				} else {
					message('不存在或已被删除', $this->createWebUrl('pk', array('op' => 'pinglun')), 'error');
				}
			} elseif ($op == 'post') {
				$id = intval($_GPC['id']);
				if (!empty($id)) {
					$item = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_pk') . " WHERE id = :id", array(':id' => $id));
					if (empty($item)) {
						message('抱歉，文章不存在或是已经删除！', '', 'error');
					}
				}
				if (checksubmit('submit')) {
					if (empty($_GPC['title'])) {
						message('标题不能为空，请输入标题!');
					}
					$data = array('weid' => $_W['weid'], 'title' => $_GPC['title'], 'url' => $_GPC['url'], 'red' => $_GPC['red'], 'blue' => $_GPC['blue'], 'red_guandian' => $_GPC['red_guandian'], 'blue_guandian' => $_GPC['blue_guandian'], 'fenxiang' => $_GPC['fenxiang'], 'body' => $_GPC['body'], 'thumb' => $_GPC['thumb'], 'displayorder' => intval($_GPC['displayorder']), 'yuedu' => intval($_GPC['yuedu']), 'time' => strtotime($_GPC['time']));
					if (empty($id)) {
						pdo_insert('siyuan_cms_pk', $data);
					} else {
						pdo_update('siyuan_cms_pk', $data, array('id' => $id));
					}
					message('文章更新成功！', url('site/entry/pk', array('op' => 'display', 'm' => 'siyuan_cms')), 'success');
				}
				include $this->template('web/news/pk');
				die;
			} else {
				if ($op == 'delete') {
					$id = intval($_GPC['id']);
					$row = pdo_fetch("SELECT id, thumb FROM " . tablename('siyuan_cms_pk') . " WHERE id = :id", array(':id' => $id));
					if (empty($row)) {
						message('抱歉，文章不存在或是已经被删除！');
					}
					if (!empty($row['thumb'])) {
						file_delete($row['thumb']);
					}
					pdo_delete('siyuan_cms_pk', array('id' => $id));
					pdo_delete('siyuan_cms_pk_pinglun', array('newsid' => $id));
					message('删除成功！', referer(), 'success');
					die;
				}
			}
		}
	}
}
$obj = new Siyuan_Cms_doWebPk();
$obj->exec();