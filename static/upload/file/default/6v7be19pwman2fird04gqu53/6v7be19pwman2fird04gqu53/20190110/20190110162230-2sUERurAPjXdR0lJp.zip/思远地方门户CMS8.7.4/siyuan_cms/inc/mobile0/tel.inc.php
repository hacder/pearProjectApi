<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileTel extends Siyuan_CmsModuleSite
{
    public function exec()
    {
        global $_W, $_GPC;
        $do = 'tel';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,tel_pay FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $psize = 15;
        if ($act == 'index') {
            $title = '便民电话';
            $fenlei = pdo_fetchall('SELECT id,name,thumb FROM ' . tablename('siyuan_cms_tel_fenlei') . " WHERE weid = '{$_W['uniacid']}' and parentid = '0' ORDER BY displayorder DESC LIMIT 100");
            $tel_nav = pdo_fetchall('SELECT id,name,thumb FROM ' . tablename('siyuan_cms_tel_fenlei') . " WHERE weid = '{$_W['uniacid']}' and parentid = '0' and status = '1' ORDER BY displayorder DESC LIMIT 100");
            foreach ($tel_nav as $re) {
                $mreply = pdo_fetchall('SELECT id,name,thumb FROM ' . tablename('siyuan_cms_tel_fenlei') . 'WHERE parentid = :parentid ORDER BY displayorder DESC LIMIT 20', array(':parentid' => $re['id']));
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['thumb'] = $mre['thumb'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                    $re['mreply'][$mre['id']]['id'] = $mre['id'];
                }
                $reply[] = $re;
            }
            $list = pdo_fetchall('SELECT id,title,tel,address,weixin,qr FROM ' . tablename('siyuan_cms_tel') . " WHERE weid = '{$_W['uniacid']}' {$condition} and status = 1 ORDER BY id DESC LIMIT  10");
            include $this->template('tel/index');
        }
        if ($act == 'list') {
            $title = '便民电话';
            $blei = intval($_GPC['blei']);
            $slei = intval($_GPC['slei']);
            if ($blei > '0') {
                $condition = " AND blei = {$blei}";
            } else {
                $condition = " AND slei = {$slei}";
            }
            $list = pdo_fetchall('SELECT id,address,tel,title,ding,qr FROM ' . tablename('siyuan_cms_tel') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY ding DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_tel') . " WHERE weid = {$_W['uniacid']} {$condition}");
            $pager = pagination($total, $pindex, $psize);
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('tel/list');
        }
        if ($act == 'tel_list') {
            $blei = intval($_GPC['blei']);
            $slei = intval($_GPC['slei']);
            if ($blei > '0') {
                $condition = " AND blei = {$blei}";
            } else {
                $condition = " AND slei = {$slei}";
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,address,tel,title,ding,qr FROM ' . tablename('siyuan_cms_tel') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY ding DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_tel') . " WHERE weid = '{$_W['weid']}' {$condition}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('tel/tel_list');
        }
        if ($act == 'so') {
            $pindex = max(1, intval($_GPC['page']));
            $psize = 20;
            $condition = '';
            $params = array();
            if (!empty($_GPC['keyword'])) {
                $condition .= ' AND title LIKE :keyword';
                $params[':keyword'] = "%{$_GPC['keyword']}%";
            }
            if (!empty($_GPC['cate_1'])) {
                $cid = intval($_GPC['cate_1']);
                $condition .= " AND blei = '{$cid}'";
            }
            $list = pdo_fetchall('SELECT id,title,tel,address,qr FROM ' . tablename('siyuan_cms_tel') . " WHERE weid = '{$_W['uniacid']}' {$condition} and status = 1 ORDER BY id DESC LIMIT  " . ($pindex - 1) * $psize . ',' . $psize, $params);
            include $this->template('tel/so');
        }
        if ($act == 'form') {
            global $_W, $_GPC;
            $list = pdo_fetchall('SELECT id,name,thumb,parentid FROM ' . tablename('siyuan_cms_tel_fenlei') . " WHERE weid = '{$_W['uniacid']}' and parentid = 0 ORDER BY displayorder DESC LIMIT 60");
            $title = '登记电话号码';
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            $media_ids = $_GPC['media_ids'];
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            if ($set['tel_pay'] > '0') {
                $ordersn = date('ymd') . random(10, 1);
                if ($_GPC['title']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['title'] = $_GPC['title'];
                    $data['tel'] = $_GPC['tel'];
                    $data['openid'] = $openid;
                    $data['ordersn'] = $ordersn;
                    $data['address'] = $_GPC['address'];
                    $data['status'] = 0;
                    foreach ($filelist as $key => $value) {
                        $data['qr'] = $value['name'];
                    }
                    pdo_insert('siyuan_cms_tel', $data);
                    $pay = array('weid' => $_W['uniacid'], 'from_user' => $openid, 'price' => $set['tel_pay'], 'title' => $_GPC['title'], 'remark' => $_GPC['title'], 'status' => 0, 'type' => 'tel', 'ordersn' => $ordersn, 'createtime' => time());
                    pdo_insert('siyuan_cms_order', $pay);
                    $orderid = pdo_insertid();
                    die(json_encode(array('status' => 1, 'id' => $orderid)));
                }
            } else {
                if ($_GPC['title']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['title'] = $_GPC['title'];
                    $data['tel'] = $_GPC['tel'];
                    $data['openid'] = $openid;
                    $data['address'] = $_GPC['address'];
                    $data['status'] = 0;
                    foreach ($filelist as $key => $value) {
                        $data['qr'] = $value['name'];
                    }
                    pdo_insert('siyuan_cms_tel', $data);
                    die(json_encode(array('status' => 2)));
                }
            }
            include $this->template('tel/form');
        }
    }
}
$obj = new Siyuan_Cms_doMobileTel();
$obj->exec();