<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhuangxiu_Gonglve extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'gonglve';
        $title = '&#x88C5;&#x4FEE;&#x653B;&#x7565;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,tel FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'gonglve') {
            $list = pdo_fetchall('SELECT id,name,pic,ad FROM ' . tablename('siyuan_cms_zhuangxiu_gonglve') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder ASC LIMIT 15");
            foreach ($list as $re) {
                $sql = 'SELECT id,gonglveid,n_title FROM ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' WHERE gonglveid = :gonglveid ORDER BY id DESC LIMIT 12';
                $params = array(':gonglveid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['n_title'] = $mre['n_title'];
                    $re['mreply'][$mre['id']]['id'] = $mre['id'];
                }
                $reply[] = $re;
            }
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $ad = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_ad') . " WHERE weid = '{$_W['weid']}' order by rand() limit 1");
            $news = pdo_fetch('SELECT id,title,time,yuedu,content,thumb,gonglveid FROM ' . tablename('siyuan_cms_zhuangxiu_gonglve_news') . ' WHERE `id` = ' . $id);
            pdo_update('siyuan_cms_zhuangxiu_gonglve_news', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
        }
        include $this->template('zhuangxiu/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhuangxiu_Gonglve();
$obj->exec();