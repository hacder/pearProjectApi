<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhuangxiu_Sheji extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'sheji';
        $title = '&#x8BBE;&#x8BA1;&#x5E08;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,tel FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_zhuangxiu_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'sheji') {
            $id = intval($_GPC['id']);
            $sheji = pdo_fetch('SELECT id,name,touxiang,gongsi,body,pinglun FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' WHERE `id` = ' . $id);
            $anli = pdo_fetchall('SELECT id,title,xiaoqu,thumb FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . " WHERE weid = '{$_W['weid']}' and shejiid = {$id} ORDER BY displayorder DESC LIMIT 15");
        }
        include $this->template('zhuangxiu/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhuangxiu_Sheji();
$obj->exec();