<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileWeixin extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '微信头条';
        $do = 'weixin';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $news_flash = pdo_fetchall('SELECT id,flash,title FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['uniacid']}' and flash != '' ORDER BY id DESC LIMIT 5");
        $psize = 20;
        if ($act == 'index') {
            $list = pdo_fetchall('SELECT id,thumb,title,yuedu,pinglun,descimgs,time,laiyuan FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE  weid = '{$_W['weid']}' ORDER BY id DESC LIMIT {$psize}");
            foreach ($list as $re) {
                $re = array('id' => $re['id'], 'thumb' => $_W['attachurl'] . $re['thumb'], 'title' => $re['title'], 'yuedu' => $re['yuedu'], 'pinglun' => $re['pinglun'], 'laiyuan' => $re['laiyuan'], 'descimgs' => unserialize($re['descimgs']), 'time' => date('m-d H:i', $re['time']));
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}' {$condition}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('weixin/index');
        }
        if ($act == 'hot') {
            $list = pdo_fetchall('SELECT id,thumb,title,yuedu,pinglun,descimgs,time,laiyuan FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE  weid = '{$_W['weid']}' ORDER BY yuedu DESC LIMIT {$psize}");
            foreach ($list as $re) {
                $re = array('id' => $re['id'], 'thumb' => $_W['attachurl'] . $re['thumb'], 'title' => $re['title'], 'yuedu' => $re['yuedu'], 'pinglun' => $re['pinglun'], 'laiyuan' => $re['laiyuan'], 'descimgs' => unserialize($re['descimgs']), 'time' => date('m-d H:i', $re['time']));
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}' {$condition}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('weixin/index_hot');
        }
        if ($act == 'list') {
            $hot = intval($_GPC['hot']);
            $wid = intval($_GPC['wid']);
            if ($hot == '1') {
                $condition = ' ORDER BY yuedu DESC';
            } elseif ($wid) {
                $condition = ' ORDER BY id DESC';
                $weixin = " and weixinid = '{$wid}'";
            } else {
                $condition = ' ORDER BY id DESC';
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,thumb,title,yuedu,pinglun,descimgs,time,laiyuan FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE  weid = '{$_W['weid']}' {$weixin} {$condition} LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}' {$weixin}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            foreach ($list as $re) {
                $re = array('id' => $re['id'], 'thumb' => $_W['attachurl'] . $re['thumb'], 'title' => $re['title'], 'yuedu' => $re['yuedu'], 'pinglun' => $re['pinglun'], 'laiyuan' => $re['laiyuan'], 'descimgs' => unserialize($re['descimgs']), 'time' => date('m-d H:i', $re['time']));
                $reply[] = $re;
            }
            include $this->template('weixin/list');
        }
        if ($act == 'gongzhonghao_index') {
            $gongzhonghao_flash = pdo_fetchall('SELECT id,flash,name FROM ' . tablename('siyuan_cms_weixin') . " WHERE weid = '{$_W['uniacid']}' and flash != '' ORDER BY id DESC LIMIT 5");
            $list = pdo_fetchall('SELECT id,displayorder,name,pic,body FROM ' . tablename('siyuan_cms_weixin') . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin') . " WHERE weid = '{$_W['weid']}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('weixin/index_gongzhonghao');
        }
        if ($act == 'gongzhonghao_list') {
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,displayorder,name,pic,body FROM ' . tablename('siyuan_cms_weixin') . " WHERE  weid = '{$_W['weid']}' ORDER BY displayorder DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('weixin/list_gongzhonghao');
        }
        if ($act == 'gongzhonghao') {
            $id = intval($_GPC['id']);
            $news = pdo_fetch('SELECT id,name,pic,body,weixin,zhuti FROM ' . tablename('siyuan_cms_weixin') . ' WHERE `id` = ' . $id);
            $list = pdo_fetchall('SELECT displayorder,id,thumb,title,yuedu,pinglun,descimgs,time FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE  weid = '{$_W['weid']}' and weixinid = '{$id}' ORDER BY id DESC LIMIT {$psize}");
            foreach ($list as $re) {
                $re = array('id' => $re['id'], 'thumb' => $_W['attachurl'] . $re['thumb'], 'title' => $re['title'], 'yuedu' => $re['yuedu'], 'pinglun' => $re['pinglun'], 'descimgs' => unserialize($re['descimgs']), 'time' => date('m-d H:i', $re['time']));
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}' and weixinid = '{$id}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('weixin/news_gongzhonghao');
        }
        if ($act == 'news') {
            $id = $_GPC['id'];
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT id,title,yuedu,time,laiyuan,pinglun,thumb,content,weixinid FROM ' . tablename('siyuan_cms_weixin_news') . ' WHERE `id` = ' . $id);
            $title = $news['title'];
            $gongzhonghao = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_weixin') . ' WHERE `id` = ' . $news['weixinid']);
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $list = pdo_fetchall('SELECT id,title,thumb,time,yuedu,pinglun,weixinid FROM ' . tablename('siyuan_cms_weixin_news') . " WHERE weid = '{$_W['weid']}' and weixinid = {$news['weixinid']} ORDER BY id DESC LIMIT 5");
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and pid = '0' and newsid = {$id} ORDER BY id DESC LIMIT {$psize}");
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$id}' and pid = '0'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            pdo_update('siyuan_cms_weixin_news', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
            include $this->template('weixin/news');
        }
        if ($act == 'pinglun_list') {
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $newsid = intval($_GPC['newsid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . " WHERE  uniacid = '{$_W['weid']}'  and newsid = '{$newsid}' and pid = '0' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$newsid}' and pid = '0'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_weixin_news_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            include $this->template('weixin/pinglun_list');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $pid = intval($_GPC['pid']);
            $num = intval($_GPC['num']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $content = $_GPC['content'];
            if ($content) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['newsid'] = $id;
                $data['pid'] = $pid;
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['content'] = $_GPC['content'];
                $data['status'] = 1;
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_weixin_news_pinglun', $data);
                pdo_update('siyuan_cms_weixin_news', array('pinglun' => $num + 1), array('id' => $id));
            }
            die(json_encode(array('status' => 1)));
        }
    }
}
$obj = new Siyuan_Cms_doMobileWeixin();
$obj->exec();