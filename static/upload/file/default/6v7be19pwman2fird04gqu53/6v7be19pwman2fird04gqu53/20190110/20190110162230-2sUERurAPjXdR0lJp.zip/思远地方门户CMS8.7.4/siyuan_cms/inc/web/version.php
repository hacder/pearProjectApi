<?php
return array (
  'ver' => '20170301',
);
?>