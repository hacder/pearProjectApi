<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileQuan extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '朋友圈';
        $do = 'quan';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $psize = 15;
      		if ((strpos($_SERVER['HTTP_USER_AGENT'],'iPhone') || strpos($_SERVER['HTTP_USER_AGENT'],'iPad'))) 
		{
			$system='ios';
		}
		else 
		{
			if (strpos($_SERVER['HTTP_USER_AGENT'],'Android')) 
			{
				$system='ad';
			}
			else 
			{
				$system='ios';
			}
		}
      
      
      
      
        if ($act == 'index') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $flash = pdo_fetchall('SELECT thumb,url FROM ' . tablename('siyuan_cms_quan_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
            $quan = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_quan') . ' WHERE `id` = ' . $id);
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $list = pdo_fetchall('SELECT id,name,avatar,body,time,type FROM ' . tablename('siyuan_cms_quan') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT {$psize}");
            foreach ($list as $re) {
                $mreply = pdo_fetchall('SELECT id,name,body FROM ' . tablename('siyuan_cms_quan_pinglun') . 'WHERE pid = :pid ORDER BY id DESC LIMIT 20', array(':pid' => $re['id']));
                $pic_list = pdo_fetchall('SELECT qid,id,pic FROM ' . tablename('siyuan_cms_quan_img') . 'WHERE qid = :qid ORDER BY id DESC LIMIT 9', array(':qid' => $re['id']));
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['body'] = $mre['body'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                foreach ($pic_list as $pic) {
                    $re['pic_list'][$pic['id']]['pic'] = $pic['pic'];
                }
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_quan') . " WHERE weid = '{$_W['weid']}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('quan/index');
        }
        if ($act == 'list') {
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,name,avatar,body,time,type FROM ' . tablename('siyuan_cms_quan') . " WHERE  weid = '{$_W['weid']}' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_quan') . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            foreach ($list as $re) {
                $mreply = pdo_fetchall('SELECT id,name,body FROM ' . tablename('siyuan_cms_quan_pinglun') . 'WHERE pid = :pid ORDER BY id DESC LIMIT 20', array(':pid' => $re['id']));
                $pic_list = pdo_fetchall('SELECT qid,id,pic FROM ' . tablename('siyuan_cms_quan_img') . 'WHERE qid = :qid ORDER BY id DESC LIMIT 9', array(':qid' => $re['id']));
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['body'] = $mre['body'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                foreach ($pic_list as $pic) {
                    $re['pic_list'][$pic['id']]['pic'] = $pic['pic'];
                }
                $reply[] = $re;
            }
            include $this->template('quan/list');
        }
        if ($act == 'form') {
            global $_W, $_GPC;
            $title = '发布信息';
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            $media_ids = $_GPC['media_ids'];
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            if ($_GPC['body']) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['openid'] = $_W['fans']['from_user'];
                $data['avatar'] = $userinfo['avatar'];
                $data['name'] = $userinfo['nickname'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                $data['type'] = 'pic';
                pdo_insert('siyuan_cms_quan', $data);
            }
            $qid = pdo_insertid();
            if ($filelist && $qid) {
                foreach ($filelist as $key => $value) {
                    $data = array();
                    $data['qid'] = $qid;
                    $data['pic'] = $value['name'];
                    $res = pdo_insert('siyuan_cms_quan_img', $data);
                }
                die(json_encode(array('status' => 1)));
            }
            include $this->template('quan/form');
        }
        if ($act == 'vod_form') {
            global $_W, $_GPC;
            load()->func('tpl');
            $title = '发布信息';
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $media_ids = $_GPC['media_ids'];
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            if ($_GPC['body']) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['openid'] = $_W['fans']['from_user'];
                $data['avatar'] = $userinfo['avatar'];
                $data['name'] = $userinfo['nickname'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                $data['type'] = 'pic';
                pdo_insert('siyuan_cms_quan', $data);
            }
            $qid = pdo_insertid();
            if ($filelist && $qid) {
                foreach ($filelist as $key => $value) {
                    $data = array();
                    $data['qid'] = $qid;
                    $data['pic'] = $value['name'];
                    $res = pdo_insert('siyuan_cms_quan_img', $data);
                }
                die(json_encode(array('status' => 1)));
            }
            include $this->template('quan/vod_form');
        }
        if ($act == 'huifu') {
            $pid = intval($_GPC['pid']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $body = $_GPC['body'];
            if ($body) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['pid'] = $_GPC['pid'];
                $data['body'] = $_GPC['body'];
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                pdo_insert('siyuan_cms_quan_pinglun', $data);
            }
            die(json_encode(array('status' => 1)));
        }
    }
}
$obj = new Siyuan_Cms_doMobileQuan();
$obj->exec();