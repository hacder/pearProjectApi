<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileXinxi_Geren extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $do = 'xinxi';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,city FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT url,attachment FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        $psize = 15;
        if ($act == 'index') {
            $title = '个人求职';
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE  weid = '{$_W['weid']}' ORDER BY ding DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE weid = '{$_W['weid']}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('xinxi/geren/index');
        }
        if ($act == 'list') {
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE  weid = '{$_W['weid']}'  ORDER BY ding DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('xinxi/geren/list');
        }
        if ($act == 'news') {
            $id = $_GPC['id'];
            $api = pdo_fetch('SELECT baidu_key,city FROM ' . tablename('siyuan_cms_api') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_xinxi_geren') . ' WHERE id = :id', array(':id' => $id));
            $url = 'http://apis.baidu.com/chazhao/mobilesearch/phonesearch?phone=' . $news['phone'];
            $ch = curl_init();
            $header = array('apikey:' . $api['baidu_key']);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $output = curl_exec($ch);
            curl_close($ch);
            $res = json_decode($output, true);
            $tel_city = $res['data']['city'];
            $tel_lx = $res['data']['operator'];
            $list = pdo_fetchall('SELECT id,title,ding,gongzi,name,time,gongzuo,xueli,zhiwei FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE  weid = '{$_W['weid']}'  ORDER BY ding DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE weid = '{$_W['weid']}'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            pdo_update('siyuan_cms_xinxi_geren', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
            include $this->template('xinxi/geren/news');
        }
        if ($act == 'form') {
            $id = intval($_GPC['id']);
            $title = '信息发布';
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            if ($_GPC['zhiwei']) {
                $data = array();
                $data['weid'] = $_W['uniacid'];
                $data['qiye'] = $_GPC['qiye'];
                $data['renshu'] = $_GPC['renshu'];
                $data['zhiwei'] = $_GPC['zhiwei'];
                $data['xueli'] = $_GPC['xueli'];
                $data['gongzi'] = $_GPC['gongzi'];
                $data['phone'] = $_GPC['phone'];
                $data['gongzuo'] = $_GPC['gongzuo'];
                $data['name'] = $_GPC['name'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_xinxi_geren', $data);
                die(json_encode(array('status' => 1)));
            }
            include $this->template('xinxi/geren/form');
        }
    }
}
$obj = new Siyuan_Cms_doMobileXinxi_Geren();
$obj->exec();