<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebKongzhi extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_W, $_GPC;
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		$huati = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_pk_pinglun') . " WHERE status = 1 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$ruzhu = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_shop') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$tougao = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_tougao') . " WHERE yuedu = 0 and uniacid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$tel = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_tel') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$yuyue = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_zhuangxiu_yuyue') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$yanfang = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_zhuangxiu_yanfang') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$baojia = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_zhuangxiu_baojia') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$tv = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_tv_bug') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$jubao = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename('siyuan_cms_tip') . " WHERE status = 0 and weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
		$context = stream_context_create(array('http' => array('timeout' => 3)));
		$lastver = file_get_contents('http://s.semall365.cn/app/index.php?i=1&c=entry&do=cms_ver&m=siyuan_admin', 0, $context);
		$version = IA_ROOT . '/addons/siyuan_cms/inc/web/version.php';
		$ver = (include $version);
		$ver = $ver['ver'];
		include $this->template('web/cms/kongzhi');
	}
}
$obj = new Siyuan_Cms_doWebKongzhi();
$obj->exec();