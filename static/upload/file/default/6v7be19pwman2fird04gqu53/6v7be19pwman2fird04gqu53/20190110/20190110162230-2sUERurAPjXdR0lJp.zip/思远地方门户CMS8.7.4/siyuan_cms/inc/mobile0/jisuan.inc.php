<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileJisuan extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '&#25151;&#36151;&#35745;&#31639;&#22120;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        if (!in_array($act, array('index', 'essfjs', 'zhd', 'gjj', 'sfjs'))) {
            message('非法请求！(' . $act . ')');
        }
        include $this->template('jisuan/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileJisuan();
$obj->exec();