<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileAdmin_Index extends siyuan_cmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '工作人员登记';
        $this->Checkeduseragent();
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $admin = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_admin') . " WHERE uniacid ={$_W['uniacid']}");
        $userinfo = mc_oauth_userinfo();
        $openid = $_W['fans']['from_user'];
        $user = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_admin') . ' WHERE openid = :openid', array(':openid' => $openid));
        if ($_GPC['name']) {
            $data = array();
            $data['uniacid'] = $_W['uniacid'];
            $data['name'] = $_GPC['name'];
            $data['username'] = $userinfo['nickname'];
            $data['tel'] = $_GPC['tel'];
            $data['openid'] = $openid;
            $data['status'] = 0;
            pdo_insert('siyuan_cms_admin', $data);
            die(json_encode(array('status' => 1)));
        }
        include $this->template('admin/admin');
    }
}
$obj = new siyuan_cms_doMobileAdmin_Index();
$obj->exec();