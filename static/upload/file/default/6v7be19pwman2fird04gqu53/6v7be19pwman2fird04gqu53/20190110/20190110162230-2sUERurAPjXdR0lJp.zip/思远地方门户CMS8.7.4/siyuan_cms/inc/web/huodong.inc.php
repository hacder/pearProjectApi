<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebHuodong extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		$fenlei = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_huodong_fenlei') . " WHERE weid = '{$_W['weid']}' ORDER BY parentid ASC, displayorder ASC, id ASC ", array(), 'id');
		if ($op == 'display') {
			$now = time();
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= ' AND title LIKE :keyword';
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			if (!empty($_GPC['cate_1'])) {
				$cid = intval($_GPC['cate_1']);
				$condition .= " AND blei = '{$cid}'";
			}
			$list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/huodong/huodong');
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$parent = array();
			$children = array();
			if (!empty($fenlei)) {
				$children = '';
				foreach ($fenlei as $cid => $cate) {
					if (!empty($cate['parentid'])) {
						$children[$cate['parentid']][] = $cate;
					} else {
						$parent[$cate['id']] = $cate;
					}
				}
			}
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_huodong') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql);
			$pics_temp = unserialize($item['descimgs']);
			$pics = array();
			if ($pics_temp) {
				foreach ($pics_temp as $pic) {
					array_push($pics, tomedia($pic));
				}
				$item['descimgs'] = $pics;
			}
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_huodong_kv') . ' WHERE `huodongid` = ' . $id . ' ORDER BY displayorder ASC';
			$item['params'] = pdo_fetchAll($sql);
			$blei = $item['blei'];
			$slei = $item['slei'];
			if (checksubmit('submit')) {
				if (empty($_GPC['name'])) {
					message('名称不能为空，请重新输入！');
				}
				$data = array('weid' => $_W['weid'], 'name' => $_GPC['name'], 'feiyong' => $_GPC['feiyong'], 'shopid' => $_GPC['shopid'], 'tel' => $_GPC['tel'], 'pic' => $_GPC['pic'], 'open' => $_GPC['open'], 'blei' => intval($_GPC['fenlei']['parentid']), 'slei' => intval($_GPC['fenlei']['childid']), 'renshu' => $_GPC['renshu'], 'yuedu' => $_GPC['yuedu'], 'lx' => $_GPC['lx'], 'flash' => $_GPC['flash'], 'address' => $_GPC['address'], 'xianzhi' => $_GPC['xianzhi'], 'time' => strtotime($_GPC['time']), 'bm_time' => strtotime($_GPC['bm_time']), 'endtime' => strtotime($_GPC['endtime']), 'province' => $_GPC['reside']['province'], 'city' => $_GPC['reside']['city'], 'district' => $_GPC['reside']['district'], 'fenxiang' => $_GPC['fenxiang'], 'video' => htmlspecialchars_decode($_GPC['video']), 'biaoti' => $_GPC['biaoti'], 'body' => htmlspecialchars_decode($_GPC['body']), 'thumb' => $_GPC['thumb'], 'music' => $_GPC['music'], 'displayorder' => $_GPC['displayorder'], 'createtime' => TIMESTAMP);
				$picpath = $_GPC['descimgs'];
				if (is_array($picpath) && !empty($picpath)) {
					$paths = array();
					foreach ($picpath as $p) {
						array_push($paths, $p[0]);
					}
					$data['descimgs'] = serialize($paths);
				}
				$geo = $_GPC['geo'];
				if (is_array($geo) && !empty($geo)) {
					$data['longitude'] = $geo['lng'];
					$data['latitude'] = $geo['lat'];
				}
				$huodong_id = $id;
				if (empty($id)) {
					pdo_insert('siyuan_cms_huodong', $data);
					$huodong_id = pdo_insertid();
				} else {
					unset($data['createtime']);
					pdo_update('siyuan_cms_huodong', $data, array('id' => $id));
				}
				$ids = array();
				if (isset($_GPC['params_key']) && $_GPC['params_key']) {
					foreach ($_GPC['params_key'] as $k => $v) {
						$data = array('weid' => $_W['weid'], 'huodongid' => $huodong_id, 'key' => $_GPC['params_key'][$k], 'value' => $_GPC['params_value'][$k], 'displayorder' => $k);
						if (empty($_GPC['params_id'][$k])) {
							pdo_insert('siyuan_cms_huodong_kv', $data);
							$ids[] = pdo_insertid();
						} else {
							pdo_update('siyuan_cms_huodong_kv', $data, array('id' => $_GPC['params_id'][$k]));
							$ids[] = $_GPC['params_id'][$k];
						}
					}
				}
				$sql = 'DELETE FROM ' . tablename('siyuan_cms_huodong_kv') . ' WHERE huodongid=:huodongid';
				if (!empty($ids)) {
					$sql .= ' AND id NOT IN(' . implode(',', $ids) . ')';
					pdo_query($sql, array(':huodongid' => $huodong_id));
				} else {
					pdo_query($sql, array(':huodongid' => $huodong_id));
				}
				message('更新成功！', url('site/entry/huodong', array('op' => 'post', 'id' => $huodong_id, 'm' => 'siyuan_cms')), 'success');
			}
			include $this->template('web/huodong/huodong');
			die;
		} elseif ($op == 'delete') {
			$id = intval($_GPC['id']);
			$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_huodong') . " WHERE id = :id", array(':id' => $id));
			if (empty($row)) {
				message('抱歉，信息不存在或是已经被删除！');
			}
			pdo_delete('siyuan_cms_huodong', array('id' => $id));
			message('删除成功！', referer(), 'success');
			die;
		} elseif ($op == 'params') {
			global $_W, $_GPC;
			include $this->template('web/huodong/huodong-params-new');
			die;
		} elseif ($op == 'deletekv') {
			$id = intval($_GPC['id']);
			if ($id > 0) {
				pdo_delete('siyuan_cms_huodong_kv', array('id' => $id));
			}
			echo 'success';
		}
	}
}
$obj = new Siyuan_Cms_doWebhuodong();
$obj->exec();