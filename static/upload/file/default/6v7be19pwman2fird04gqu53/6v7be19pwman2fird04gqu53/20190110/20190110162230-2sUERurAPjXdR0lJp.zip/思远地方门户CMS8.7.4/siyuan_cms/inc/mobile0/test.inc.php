<?php

defined('IN_IA') or die('Access Denied');
include_once IA_ROOT . '/addons/siyuan_cms/inc/mobile/api.php';
class Siyuan_Cms_doMobileTest extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        header('Content-type:text/html;charset=utf-8');
        $appkey = '45e221f90b621c712a50f6cfd2133f23';
        $url = 'http://op.juhe.cn/onebox/weather/query';
        $params = array('cityname' => '利川', 'key' => $appkey, 'dtype' => '');
        $paramstring = http_build_query($params);
        $content = juhecurl($url, $paramstring);
        $result = json_decode($content, true);
        if ($result) {
            if ($result['error_code'] == '0') {
                print_r($result);
            } else {
                echo $result['error_code'] . ':' . $result['reason'];
            }
        } else {
            echo '请求失败';
        }
        include $this->template('test');
    }
}
$obj = new Siyuan_Cms_doMobileTest();
$obj->exec();