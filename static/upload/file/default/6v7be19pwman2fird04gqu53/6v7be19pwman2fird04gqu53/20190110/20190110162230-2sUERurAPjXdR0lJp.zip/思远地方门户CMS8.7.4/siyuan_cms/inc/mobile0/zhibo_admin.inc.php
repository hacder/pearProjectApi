<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhibo_Admin extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '&#30452;&#25773;&#20154;&#21592;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $act = $_GPC['act'] ? $_GPC['act'] : 'admin';
        if ($act == 'admin') {
            global $_W, $_GPC;
            $openid = $_W['openid'];
            $userinfo = mc_oauth_userinfo();
            $this->Checkeduseragent();
            $admin = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_zhibo_admin') . " WHERE weid ={$_W['weid']}");
            if (checksubmit('submit')) {
                $data = array('weid' => $_W['weid'], 'uid' => $_W['member']['uid'], 'name' => $_GPC['name'], 'tel' => $_GPC['tel'], 'openid' => $_W['fans']['from_user'], 'state' => 1);
                pdo_insert('siyuan_cms_zhibo_admin', $data);
                $new_id = pdo_insertid();
                if ($new_id) {
                    message('提交成功！', $this->createMobileUrl('zhibo', array('act' => 'admin'), true), 'success');
                } else {
                    message('系统错误，请稍后重试', referer(), 'error');
                }
            }
        }
        include $this->template('zhibo/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhibo_Admin();
$obj->exec();