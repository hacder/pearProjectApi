<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileIndex extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $do = 'index';
        $set = pdo_fetch('SELECT name,ad,logo,city FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $title = $set['name'];
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $index_set = pdo_fetch('SELECT ad_1,ad_2,ad_url_1,ad_url_2,city,qiandao FROM ' . tablename('siyuan_cms_index') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $index_nav = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 100");
        $flash = pdo_fetchall('SELECT id,url,thumb FROM ' . tablename('siyuan_cms_index_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $news = pdo_fetchall('SELECT id,title,yuedu,pinglun,time,thumb FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 6");
        $city_list = pdo_fetchall('SELECT id,displayorder,thumb,title,url FROM ' . tablename('siyuan_cms_city') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 16");
        $api = pdo_fetch('SELECT baidu_key,city FROM ' . tablename('siyuan_cms_api') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $url = 'http://apis.baidu.com/apistore/weatherservice/cityname?cityname=' . $api['city'];
        $ch = curl_init();
        $header = array('apikey:' . $api['baidu_key']);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $output = curl_exec($ch);
        curl_close($ch);
        $res = json_decode($output, true);
        $weather_weather = $res['retData']['weather'];
        $weather_temp = $res['retData']['temp'];
        $weekarray = array('日', '一', '二', '三', '四', '五', '六');
        $weather_week = '星期' . $weekarray[date('w')];
        $weather_day = date('d');
        include $this->template('index');
    }
}
$obj = new Siyuan_Cms_doMobileIndex();
$obj->exec();