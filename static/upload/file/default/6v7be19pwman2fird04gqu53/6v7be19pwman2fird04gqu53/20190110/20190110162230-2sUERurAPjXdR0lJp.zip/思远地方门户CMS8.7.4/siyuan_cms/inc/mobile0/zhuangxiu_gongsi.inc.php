<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhuangxiu_Gongsi extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'gongsi_list';
        $title = '&#x88C5;&#x4FEE;&#x516C;&#x53F8;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,tel FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'gongsi') {
            $id = intval($_GPC['id']);
            $gongsi = pdo_fetch('SELECT id,name,pic,gongdi,anli,yezhu,body FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi') . ' WHERE `id` = ' . $id);
            $anli = pdo_fetchall('SELECT id,title,xiaoqu,thumb FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' WHERE `gongsiid` = ' . $id);
            $sheji = pdo_fetchall('SELECT id,name,thumb,touxiang,tedian FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_sheji') . ' WHERE `gongsiid` = ' . $id);
        }
        if ($act == 'gongsi_list') {
        }
        if ($act == 'ajax') {
            global $_GPC, $_W;
            $page = intval($_GET['page']);
            $pagenum = 8;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi') . " WHERE weid = '{$_W['weid']}' ORDER BY displayorder DESC,id desc LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    $arr[] = array('url' => $this->createMobileUrl('zhuangxiu_gongsi', array('id' => $item['id'], 'act' => 'gongsi')), 'name' => $item['name'], 'ad' => $item['ad'], 'address' => $item['address'], 'thumb' => $_W['attachurl'] . $item['thumb']);
                }
                echo json_encode($arr);
            }
        }
        include $this->template('zhuangxiu/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhuangxiu_Gongsi();
$obj->exec();