<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileAdmin_News extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $openid = $_W['fans']['from_user'];
        $admin = pdo_fetchcolumn('SELECT state FROM ' . tablename('siyuan_cms_admin') . " WHERE openid ='{$openid}' and state = '2'");
        if ($admin == '0') {
            message('', $this->createMobileUrl('index'), 'success');
        }
        $set = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        if ($act == 'index') {
            $pindex = max(1, intval($_GPC['page']));
            $psize = 30;
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
            }
        }
        if ($act == 'pinglun') {
            $id = intval($_GPC['id']);
            if ($id > 0) {
                $condition = " AND newsid = {$id}";
            }
            $news = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}' ORDER BY id ASC ", array(), 'id');
            $pindex = max(1, intval($_GPC['page']));
            $psize = 30;
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' {$condition} ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' {$condition}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
            }
        }
        if ($act == 'del') {
            global $_W, $_GPC;
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_news', array('id' => $id));
            pdo_delete('siyuan_cms_news_pinglun', array('newsid' => $id));
            message('', referer(), 'success');
        }
        if ($act == 'pldel') {
            global $_W, $_GPC;
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_news_pinglun', array('id' => $id));
            message('', referer(), 'success');
        }
        if ($act == 'tuijian') {
            $id = intval($_GPC['id']);
            $tj = intval($_GPC['tj']);
            pdo_update('siyuan_cms_news', array('tuijian' => $tj), array('id' => $id));
            message('', referer(), 'success');
        }
        include $this->template('admin/news/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileAdmin_News();
$obj->exec();