<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobiletuan extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $do = 'tuan';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        if ($act == 'index') {
            $openid = $_W['openid'];
            $id = intval($_GPC['id']);
            $tuan = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_tuan') . ' WHERE `id` = ' . $id);
            $title = $tuan['title'];
            $dingdan = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_order') . " WHERE weid = '{$_W['uniacid']}' and `from_user` = '{$openid}' and type = 'tuan'");
            $name = $_GPC['name'];
            $pinpai_list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tuan_pinpai') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 100");
            $gongsi_list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tuan_gongsi') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 10");
            $huodong_list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tuan_huodong') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 10");
            if ($name) {
                $ordersn = date('ymd') . random(10, 1);
                $data = array('weid' => $_W['uniacid'], 'from_user' => $openid, 'price' => $tuan['money'], 'title' => $tuan['title'], 'remark' => $_GPC['name'] . $_GPC['tel'], 'status' => 0, 'type' => 'tuan', 'ordersn' => $ordersn, 'createtime' => time());
                pdo_insert('siyuan_cms_order', $data);
                $orderid = pdo_insertid();
                if ($orderid) {
                    die(json_encode(array('status' => 1, 'id' => $orderid)));
                } else {
                    die(json_encode(array('status' => 2)));
                }
            }
        }
        if ($act == 'map') {
            $id = intval($_GPC['id']);
            $tuan = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_tuan') . ' WHERE `id` = ' . $id);
        }
        include $this->template('tuan/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobiletuan();
$obj->exec();