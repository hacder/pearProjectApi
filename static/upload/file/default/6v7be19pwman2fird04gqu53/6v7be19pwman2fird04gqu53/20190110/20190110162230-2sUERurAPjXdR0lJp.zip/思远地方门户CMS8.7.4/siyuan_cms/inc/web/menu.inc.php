<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebMenu extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_W, $_GPC;
		$operation = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($operation == 'display') {
			if (!empty($_GPC['displayorder'])) {
				foreach ($_GPC['displayorder'] as $id => $displayorder) {
					pdo_update('siyuan_cms_menu', array('displayorder' => $displayorder), array('id' => $id));
				}
				message('', 'refresh', 'success');
			}
			$list = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC,id DESC ");
		} elseif ($operation == 'post') {
			$id = intval($_GPC['id']);
			if (checksubmit('submit')) {
				$data = array('weid' => $_W['uniacid'], 'title' => $_GPC['title'], 'url' => $_GPC['url'], 'thumb' => $_GPC['thumb']);
				if (!empty($id)) {
					pdo_update('siyuan_cms_menu', $data, array('id' => $id));
				} else {
					pdo_insert('siyuan_cms_menu', $data);
					$id = pdo_insertid();
				}
				message('', $this->createWebUrl('menu', array('op' => 'display')), 'success');
			}
			$adv = pdo_fetch("select * from " . tablename('siyuan_cms_menu') . " where id=:id and weid=:weid", array(":id" => $id, ":weid" => $_W['uniacid']));
		} elseif ($operation == 'xianshi') {
			$id = intval($_GPC['id']);
			$sql = "SELECT * FROM " . tablename('siyuan_cms_menu') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql, array());
			if (empty($item)) {
				message('抱歉，信息不存在或是已经被删除！');
			}
			pdo_update('siyuan_cms_menu', array('id' => $id, 'xian' => 1), array('id' => $id));
			message('显示成功！', referer(), 'success');
			die;
		} elseif ($operation == 'quxiao') {
			$id = intval($_GPC['id']);
			$sql = "SELECT * FROM " . tablename('siyuan_cms_menu') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql, array());
			if (empty($item)) {
				message('抱歉，信息不存在或是已经被删除！');
			}
			pdo_update('siyuan_cms_menu', array('id' => $id, 'xian' => 0), array('id' => $id));
			message('取消显示！', referer(), 'success');
			die;
		} elseif ($operation == 'delete') {
			$id = intval($_GPC['id']);
			$adv = pdo_fetch("SELECT id  FROM " . tablename('siyuan_cms_menu') . " WHERE id = '{$id}' AND weid=" . $_W['uniacid'] . "");
			if (empty($adv)) {
				message('抱歉，不存在或是已经被删除！', $this->createWebUrl('menu', array('op' => 'display')), 'error');
			}
			pdo_delete('siyuan_cms_menu', array('id' => $id));
			message('删除成功！', $this->createWebUrl('menu', array('op' => 'display')), 'success');
		} else {
			message('请求方式不存在');
		}
		include $this->template('web/cms/menu');
	}
}
$obj = new Siyuan_Cms_doWebMenu();
$obj->exec();