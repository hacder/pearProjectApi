<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileShop extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '商家';
        $do = 'shop';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,shop_pay FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $index_menu = pdo_fetchall('SELECT displayorder,thumb,url,title,xian FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 50");
        $psize = 10;
        if ($act == 'index') {
            $index_flash = pdo_fetchall('SELECT id,flash FROM ' . tablename('siyuan_cms_shop') . " WHERE weid = '{$_W['uniacid']}' and flash != '' ORDER BY id DESC LIMIT 5");
            $list_fenlei = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop_fenlei') . " WHERE  weid = '{$_W['weid']}' and parentid = '0' ORDER BY displayorder DESC ,id DESC LIMIT 100");
            $list_news = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and status = '1' ORDER BY id DESC LIMIT {$psize}");
            $list_hot = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and status = '1' ORDER BY yuedu DESC ,displayorder DESC LIMIT {$psize}");
            $list_tj = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and status = '1' ORDER BY ding DESC ,displayorder DESC LIMIT {$psize}");
            include $this->template('shop/index');
        }
        if ($act == 'list') {
            $bid = intval($_GPC['bid']);
            $lx = $_GPC['lx'];
            if ($lx == 'ding') {
                $condition = ' ORDER BY ding DESC, displayorder DESC, id DESC LIMIT';
            } elseif ($lx == 'hot') {
                $condition = ' ORDER BY yuedu DESC, id DESC LIMIT';
            } else {
                $condition = ' ORDER BY id DESC LIMIT';
            }
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and blei = {$bid} and status = '1' {$condition} {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_shop') . " WHERE weid = '{$_W['weid']}' and status = '1' and blei = {$bid}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('shop/list');
        }
        if ($act == 'shop_list') {
            $bid = intval($_GPC['bid']);
            $lx = $_GPC['lx'];
            if ($lx == 'news' || $lx == '') {
                $condition = ' ORDER BY id DESC LIMIT';
            } elseif ($lx == 'hot') {
                $condition = ' ORDER BY yuedu DESC, id DESC LIMIT';
            } else {
                $condition = ' ORDER BY ding DESC, displayorder DESC, id DESC LIMIT';
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_shop') . " WHERE  weid = '{$_W['weid']}' and blei = {$bid} and status = '1' {$condition} " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_shop') . " WHERE weid = '{$_W['weid']}' and status = '1' and blei = {$bid}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('shop/shop_list');
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $shop = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_shop') . ' WHERE `id` = ' . $id);
            $title = $shop['name'];
            $pics_temp = unserialize($shop['descimgs']);
            $pics = array();
            if ($pics_temp) {
                foreach ($pics_temp as $pic) {
                    array_push($pics, tomedia($pic));
                }
                $shop['descimgs'] = $pics;
            }
            $item['kvs'] = pdo_fetchAll('SELECT * FROM ' . tablename('siyuan_cms_shop_kv') . ' WHERE `shopid` = ' . $id . ' ORDER BY displayorder ASC');
            $huodong = pdo_fetchall('SELECT id,displayorder,name,time,address,thumb,bm_time,endtime,open FROM ' . tablename('siyuan_cms_huodong') . " WHERE weid = '{$_W['weid']}' and shopid = {$shop['id']} ORDER BY id DESC LIMIT 5");
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_shop_pinglun') . " WHERE uniacid = '{$_W['weid']}' and pid = '0' and shopid = {$id} ORDER BY id DESC LIMIT {$psize}");
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_shop_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_shop_pinglun') . " WHERE uniacid = '{$_W['weid']}' and shopid = '{$id}' and pid = '0'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            pdo_update('siyuan_cms_shop', array('yuedu' => $shop['yuedu'] + 1), array('id' => $id));
            include $this->template('shop/news');
        }
        if ($act == 'map') {
            $id = intval($_GPC['id']);
            $shop = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_shop') . ' WHERE `id` = ' . $id);
            include $this->template('shop/map');
        }
        if ($act == 'pinglun_list') {
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $shopid = intval($_GPC['shopid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_shop_pinglun') . " WHERE  uniacid = '{$_W['weid']}'  and shopid = '{$shopid}' and pid = '0' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_shop_pinglun') . " WHERE uniacid = '{$_W['weid']}' and shopid = '{$shopid}' and pid = '0'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_shop_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(':pid' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            include $this->template('news/pinglun_list');
        }
        if ($act == 'form') {
            global $_W, $_GPC;
            $title = '商家入驻';
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                message('', $this->createMobileUrl('index'), 'success');
            }
            $media_ids = $_GPC['media_ids'];
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            if ($set['shop_pay'] > '0') {
                $ordersn = date('ymd') . random(10, 1);
                if ($_GPC['name']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['name'] = $_GPC['name'];
                    $data['tel'] = $_GPC['tel'];
                    $data['yingye'] = $_GPC['yingye'];
                    $data['body'] = $_GPC['body'];
                    $data['weixin'] = $_GPC['weixin'];
                    $data['openid'] = $openid;
                    $data['ordersn'] = $ordersn;
                    $data['address'] = $_GPC['address'];
                    $data['status'] = 0;
                    $mid = pdo_insert('siyuan_cms_shop', $data);
                    if ($filelist && $mid) {
                        foreach ($filelist as $key => $value) {
                            $data = array();
                            $data['mid'] = $mid;
                            $data['pic'] = $value['name'];
                            $res = pdo_insert('siyuan_cms_shop_img', $data);
                        }
                    }
                    $pay = array('weid' => $_W['uniacid'], 'from_user' => $openid, 'price' => $set['shop_pay'], 'title' => $_GPC['name'], 'remark' => $_GPC['name'], 'status' => 0, 'type' => 'shop', 'ordersn' => $ordersn, 'createtime' => time());
                    pdo_insert('siyuan_cms_order', $pay);
                    $orderid = pdo_insertid();
                    die(json_encode(array('status' => 1, 'id' => $orderid)));
                }
            } else {
                if ($_GPC['name']) {
                    $data = array();
                    $data['weid'] = $_W['uniacid'];
                    $data['name'] = $_GPC['name'];
                    $data['tel'] = $_GPC['tel'];
                    $data['yingye'] = $_GPC['yingye'];
                    $data['body'] = $_GPC['body'];
                    $data['weixin'] = $_GPC['weixin'];
                    $data['openid'] = $openid;
                    $data['address'] = $_GPC['address'];
                    $data['status'] = 0;
                    pdo_insert('siyuan_cms_shop', $data);
                    $mid = pdo_insertid();
                    if ($filelist && $mid) {
                        foreach ($filelist as $key => $value) {
                            $data = array();
                            $data['mid'] = $mid;
                            $data['pic'] = $value['name'];
                            $res = pdo_insert('siyuan_cms_shop_img', $data);
                        }
                    }
                    die(json_encode(array('status' => 2)));
                }
            }
            include $this->template('shop/form');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $pid = intval($_GPC['pid']);
            $num = intval($_GPC['num']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            if ($_GPC['content']) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['shopid'] = $id;
                $data['pid'] = $pid;
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['content'] = $_GPC['content'];
                $data['status'] = 1;
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_shop_pinglun', $data);
                pdo_update('siyuan_cms_shop', array('pinglun' => $num + 1), array('id' => $id));
            }
            die(json_encode(array('status' => 1)));
        }
    }
}
$obj = new Siyuan_Cms_doMobileShop();
$obj->exec();