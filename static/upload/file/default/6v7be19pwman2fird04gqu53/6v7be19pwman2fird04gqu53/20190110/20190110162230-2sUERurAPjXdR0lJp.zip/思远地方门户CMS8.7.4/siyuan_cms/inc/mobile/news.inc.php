<?php
// decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or exit('Access Denied');

class Siyuan_Cms_doMobileNews extends Siyuan_CmsModuleSite
{

    public function __construct()
    {
        parent::__construct();
    }

    public function exec()
    {
        global $_W, $_GPC;
        $title = '新闻资讯';
        $do = 'news';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall("SELECT displayorder,thumb,url,title FROM " . tablename('siyuan_cms_top_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC LIMIT 16");
        $nav = pdo_fetchall("SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM " . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $share = pdo_fetch("SELECT news_title,news_pic FROM " . tablename('siyuan_cms_share_set') . " WHERE weid = :weid ", array(
            ':weid' => $_W['uniacid']
        ));
        $set = pdo_fetch("SELECT name,ad,logo,qr,color,gz_open,gz_name,gz_ad,gz_btn,gz_logo FROM " . tablename('siyuan_cms_setting') . " WHERE weid = :weid ", array(
            ':weid' => $_W['uniacid']
        ));
        $flash = pdo_fetchall("SELECT attachment,url FROM " . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $news_fenlei = pdo_fetchall("SELECT id,name,displayorder,wurl FROM " . tablename('siyuan_cms_news_fenlei') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC ,id DESC LIMIT 20");
        $psize = 20;
        if ($act == 'index') {
            $bid = intval($_GPC['bid']);
            if (! empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $news_flash = pdo_fetchall("SELECT id,flash,title FROM " . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['uniacid']}' and flash != '' ORDER BY id DESC LIMIT 5");
            $list = pdo_fetchall('SELECT displayorder,id,thumb,title,yuedu,pinglun,descimgs,time,tuijian,wurl FROM ' . tablename('siyuan_cms_news') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT {$psize}");
            foreach ($list as $re) {
                if(empty($re['thumb'])){
                    $re['thumb']=$_W['siteroot'].'addons/siyuan_cms/ui/img/index/news.png';
                }else{
                    $re['thumb']=$_W['attachurl'] . $re['thumb'];
                }
                $re = array(
                    'id' => $re['id'],
                    'thumb' => $re['thumb'],
                    'title' => $re['title'],
                    'yuedu' => $re['yuedu'],
                    'pinglun' => $re['pinglun'],
                    'tuijian' => $re['tuijian'],
                    'wurl' => $re['wurl'],
                    'descimgs' => unserialize($re['descimgs']),
                    'time' => date('m-d H:i', $re['time'])
                );
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}' {$condition}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('news/index');
        }
        if ($act == 'list') {
            $bid = intval($_GPC['bid']);
            if (! empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT displayorder,id,thumb,wurl,title,yuedu,pinglun,descimgs,time,tuijian FROM ' . tablename('siyuan_cms_news') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}' {$condition}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend ++;
                json_encode(array(
                    'status' => '200'
                ));
            } else {
                json_encode(array(
                    'status' => '100'
                ));
            }
            foreach ($list as $re) {
                if(empty($re['thumb'])){
                    $re['thumb']=$_W['siteroot'].'addons/siyuan_cms/ui/img/index/news.png';
                }else{
                    $re['thumb']=$_W['attachurl'] . $re['thumb'];
                }
                $re = array(
                    'id' => $re['id'],
                    'thumb' => $re['thumb'],
                    'title' => $re['title'],
                    'yuedu' => $re['yuedu'],
                    'pinglun' => $re['pinglun'],
                    'tuijian' => $re['tuijian'],
                    'wurl' => $re['wurl'],
                    'descimgs' => unserialize($re['descimgs']),
                    'time' => date('m-d H:i', $re['time'])
                );
                $reply[] = $re;
            }
            include $this->template('news/list');
        }
        if ($act == 'pinglun_list') {
           $userinfo = mc_oauth_userinfo();
        $openid = $userinfo['openid'];
            $black_list = pdo_fetchcolumn("SELECT status FROM " . tablename('siyuan_cms_black_list') . " WHERE openid = :openid", array(
                ':openid' => $openid
            ));
            if ($black_list >= '1' || $openid == '') {
                $user = "0";
            }
            $admin = pdo_fetchcolumn("SELECT status FROM " . tablename('siyuan_cms_admin') . " WHERE openid = :openid", array(
                ':openid' => $openid
            ));
            $newsid = intval($_GPC['newsid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,content,pid,name,avatar,time FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE  uniacid = '{$_W['weid']}'  and newsid = '{$newsid}' and pid = '0' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$newsid}' and pid = '0'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend ++;
                json_encode(array(
                    'status' => '200'
                ));
            } else {
                json_encode(array(
                    'status' => '100'
                ));
            }
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_news_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(
                    ':pid' => $re['id']
                );
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['id'] = $mre['id'];
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            include $this->template('news/pinglun_list');
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
           $userinfo = mc_oauth_userinfo();
        $openid = $userinfo['openid'];
            $news = pdo_fetch("SELECT id,title,yuedu,time,laiyuan,pinglun,thumb,blei,content FROM " . tablename('siyuan_cms_news') . ' WHERE `id` = ' . $id);
            $black_list = pdo_fetchcolumn("SELECT status FROM " . tablename('siyuan_cms_black_list') . " WHERE openid = :openid", array(
                ':openid' => $openid
            ));
            if ($black_list >= '1' || $openid == '') {
                $user = "0";
            }
            $admin = pdo_fetchcolumn("SELECT status FROM " . tablename('siyuan_cms_admin') . " WHERE openid = :openid", array(
                ':openid' => $openid
            ));
            $list = pdo_fetchall("SELECT id,title,thumb,time,yuedu,pinglun FROM " . tablename('siyuan_cms_news') . " WHERE weid = '{$_W['weid']}' and tuijian='1' ORDER BY id DESC LIMIT 5");
            $pinglun_list = pdo_fetchall("SELECT id,content,pid,name,avatar,time FROM " . tablename('siyuan_cms_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and pid = '0' and newsid = {$id} ORDER BY id DESC LIMIT {$psize}");
            foreach ($pinglun_list as $re) {
                $sql = 'SELECT id,pid,content,name FROM ' . tablename('siyuan_cms_news_pinglun') . ' WHERE pid = :pid ORDER BY id DESC LIMIT 20';
                $params = array(
                    ':pid' => $re['id']
                );
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['id'] = $mre['id'];
                    $re['mreply'][$mre['id']]['content'] = $mre['content'];
                    $re['mreply'][$mre['id']]['name'] = $mre['name'];
                }
                $reply[] = $re;
            }
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$id}' and pid = '0'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            $num_yuedu = rand(1, 10);
            pdo_update('siyuan_cms_news', array(
                'yuedu' => $news['yuedu'] + $num_yuedu
            ), array(
                'id' => $news['id']
            ));
            include $this->template('news/news');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $pid = intval($_GPC['pid']);
            $num = intval($_GPC['num']);
            $userinfo = mc_oauth_userinfo();
        $openid = $userinfo['openid'];
            $content = $_GPC['content'];
            if ($content) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['newsid'] = $id;
                $data['pid'] = $pid;
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['content'] = $_GPC['content'];
                $data['status'] = 1;
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_news_pinglun', $data);
                pdo_update('siyuan_cms_news', array(
                    'pinglun' => $num + 1
                ), array(
                    'id' => $id
                ));
                $users = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_news_pinglun') . " WHERE id = {$pid}");
                if ($pid) {
                    $xiaoxi = pdo_fetch("SELECT pinglun_xiaoxi FROM " . tablename('siyuan_cms_xiaoxi') . " WHERE weid = :weid ", array(
                        ':weid' => $_W['uniacid']
                    ));
                    $xiaoxi = array(
                        'touser' => $users['openid'],
                        'template_id' => $xiaoxi['pinglun_xiaoxi'],
                        'url' => $_W['siteroot'] . 'app/' . $this->createMobileUrl('news', array(
                            'act' => 'news',
                            'id' => $id
                        )),
                        'topcolor' => '#FF0000'
                    );
                    $xiaoxi['data'] = array(
                        'first' => array(
                            'value' => '您好，您的评论有人回复了！'
                        ),
                        'keyword1' => array(
                            'value' => $users['name'],
                            'color' => '#173177'
                        ),
                        'keyword2' => array(
                            'value' => date('Y-m-d H:i:s', time()),
                            'color' => '#173177'
                        ),
                        'keyword3' => array(
                            'value' => $_GPC['content'],
                            'color' => '#173177'
                        ),
                        'remark' => array(
                            'value' => '点击查看详情'
                        )
                    );
                    $token = $this->getToken();
                    $this->sendMBXX($token, $xiaoxi);
                }
            }
            exit(json_encode(array(
                'status' => 1
            )));
        }
        if ($act == 'pinglun_del') {
            global $_W, $_GPC;
            $id = $_GPC['id'];
            pdo_delete('siyuan_cms_news_pinglun', array(
                'id' => $id
            ));
            message('', referer(), 'success');
        }
        if ($act == 'black') {
            global $_W, $_GPC;
            $id = $_GPC['id'];
            $news = pdo_fetch("SELECT id,openid,name FROM " . tablename('siyuan_cms_news_pinglun') . ' WHERE `id` = ' . $id);
            $data = array(
                'weid' => $_W['weid'],
                'openid' => $news['openid'],
                'beizhu' => $news['name'],
                'status' => 1
            );
            pdo_insert('siyuan_cms_black_list', $data);
            message('成功', referer(), 'success');
        }
    }
}
$obj = new Siyuan_Cms_doMobileNews();
$obj->exec();