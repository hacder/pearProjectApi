<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileAdmin extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $this->Checkeduseragent();
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $openid = $_W['fans']['from_user'];
        $admin = pdo_fetchcolumn('SELECT state FROM ' . tablename('siyuan_cms_admin') . " WHERE openid ='{$openid}' and state = '2'");
        if ($admin == '0') {
            message('', $this->createMobileUrl('index'), 'success');
        }
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        if ($act == 'index') {
        }
        include $this->template('admin/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileAdmin();
$obj->exec();