<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
load()->model('mc');
class Siyuan_Cms_doWebSai_User extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($op == 'display') {
			$sid = intval($_GPC['sid']);
			$pindex = max(1, intval($_GPC['page']));
			$psize = 100;
			$list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_sai_user') . " WHERE weid = '{$_W['weid']}' and sid = {$sid} ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$baoming = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_sai') . " WHERE weid = '{$_W['weid']}' and id = {$sid}");
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_sai_user') . " WHERE weid = '{$_W['weid']}'", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/sai/user');
		} else {
			if ($op == 'toexcel') {
				$condition = ' WHERE `weid`=' . $_W['uniacid'];
				$sql = "SELECT * FROM " . tablename('siyuan_cms_sai_user') . $condition;
				$list = pdo_fetchall($sql);
				foreach ($list as &$or) {
					$or['time'] = date('Y-m-d H:i:s', $or['time']);
					$or['huodong'] = $fenlei[$or['huodongid']]['name'];
					switch ($or['status']) {
						case '1':
							$or['status'] = '已确认';
							break;
						case '0':
							$or['status'] = '未通过';
							break;
					}
				}
				require_once IA_ROOT . '/framework/library/phpexcel/PHPExcel.php';
				require_once IA_ROOT . '/framework/library/phpexcel/PHPExcel/IOFactory.php';
				require_once IA_ROOT . '/framework/library/phpexcel/PHPExcel/Writer/Excel5.php';
				$resultPHPExcel = new PHPExcel();
				$styleArray = array('borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN)));
				$style_fill = array('fill' => array('type' => PHPExcel_Style_Fill::FILL_SOLID, 'color' => array('argb' => '0xFFFF00')));
				$resultPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($styleArray + $style_fill);
				$resultPHPExcel->getActiveSheet()->setCellValue('A1', '微信昵称');
				$resultPHPExcel->getActiveSheet()->setCellValue('B1', '姓名');
				$resultPHPExcel->getActiveSheet()->setCellValue('C1', '电话');
				$resultPHPExcel->getActiveSheet()->setCellValue('D1', '报名活动');
				$resultPHPExcel->getActiveSheet()->setCellValue('E1', '报名时间');
				$resultPHPExcel->getActiveSheet()->setCellValue('F1', '是否通过');
				$resultPHPExcel->getActiveSheet()->setCellValue('G1', '报名留言');
				$i = 2;
				foreach ($list as $item) {
					$resultPHPExcel->getActiveSheet()->setCellValue('A' . $i, $item['username']);
					$resultPHPExcel->getActiveSheet()->setCellValue('B' . $i, $item['name']);
					$resultPHPExcel->getActiveSheet()->setCellValue('C' . $i, $item['tel']);
					$resultPHPExcel->getActiveSheet()->setCellValue('D' . $i, $item['huodong']);
					$resultPHPExcel->getActiveSheet()->setCellValue('E' . $i, $item['time']);
					$resultPHPExcel->getActiveSheet()->setCellValue('F' . $i, $item['status']);
					$resultPHPExcel->getActiveSheet()->setCellValue('G' . $i, $item['body']);
					$resultPHPExcel->getActiveSheet()->getStyle('A' . $i . ':G' . $i)->applyFromArray($styleArray);
					$i++;
				}
				$resultPHPExcel->getActiveSheet()->setCellValue('A' . $i, '总报名人数：' . count($list) . '人');
				$resultPHPExcel->getActiveSheet()->getStyle('A' . $i)->applyFromArray(array('font' => array('bold' => true)));
				$outputFileName = 'total.xls';
				$xlsWriter = new PHPExcel_Writer_Excel5($resultPHPExcel);
				header('Content-Type: application/force-download');
				header('Content-Type: application/octet-stream');
				header('Content-Type: application/download');
				header('Content-Disposition:inline;filename="' . $outputFileName . '"');
				header('Content-Transfer-Encoding: binary');
				header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
				header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: no-cache');
				$xlsWriter->save("php://output");
			} else {
				if ($op == 'tongguo') {
					$id = intval($_GPC['id']);
					$sql = "SELECT * FROM " . tablename('siyuan_cms_sai_user') . ' WHERE `id` = ' . $id;
					$item = pdo_fetch($sql, array());
					if (empty($item)) {
						message('抱歉，信息不存在或是已经被删除！');
					}
					pdo_update('siyuan_cms_sai_user', array('id' => $id, 'status' => 1), array('id' => $id));
					message('通过！', referer(), 'success');
					die;
				} else {
					if ($op == 'quxiao') {
						$id = intval($_GPC['id']);
						$sql = "SELECT * FROM " . tablename('siyuan_cms_sai_user') . ' WHERE `id` = ' . $id;
						$item = pdo_fetch($sql, array());
						if (empty($item)) {
							message('抱歉，信息不存在或是已经被删除！');
						}
						pdo_update('siyuan_cms_sai_user', array('id' => $id, 'status' => 0), array('id' => $id));
						message('取消！', referer(), 'success');
						die;
					} else {
						if ($op == 'delete') {
							$id = intval($_GPC['id']);
							$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_sai_user') . " WHERE id = :id", array(':id' => $id));
							if (empty($row)) {
								message('抱歉，信息不存在或是已经被删除！');
							}
							pdo_delete('siyuan_cms_sai_user', array('id' => $id));
							message('删除成功！', referer(), 'success');
							die;
						}
					}
				}
			}
		}
	}
}
$obj = new Siyuan_Cms_doWebSai_User();
$obj->exec();