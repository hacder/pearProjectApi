<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileTougao extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'tougao';
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        if ($act == 'tougao') {
            global $_W, $_GPC;
            load()->func('file');
            load()->func('tpl');
            $title = '在线投稿';
            $userinfo = mc_oauth_userinfo();
            $media_ids = $_GPC['media_ids'];
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            $moments_type = $filelist ? 'image' : 'text';
            if ($_GPC['title']) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['title'] = $_GPC['title'];
                $data['openid'] = $_W['fans']['from_user'];
                $data['username'] = $_W['fans']['nickname'];
                $data['avatar'] = $userinfo['avatar'];
                $data['name'] = $_GPC['name'];
                $data['weixin'] = $_GPC['weixin'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_tougao', $data);
            }
            $mid = pdo_insertid();
            if ($filelist && $mid) {
                foreach ($filelist as $key => $value) {
                    $data = array();
                    $data['mid'] = $mid;
                    $data['pic'] = $value['name'];
                    $res = pdo_insert('siyuan_cms_tougao_img', $data);
                }
            }
            include $this->template('cms/tougao');
        }
        if ($act == 'edit') {
            global $_W, $_GPC;
            load()->func('file');
            load()->func('tpl');
            $title = '修改信息';
            $userinfo = mc_oauth_userinfo();
            $id = intval($_GET['id']);
            $media_ids = $_GPC['media_ids'];
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_tougao') . ' WHERE `id` = ' . $id);
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_tougao_img') . " WHERE mid = {$news['id']} ORDER BY id DESC LIMIT 9");
            $filelist = array();
            if ($media_ids) {
                $filelist = $this->downloadFromWxServer($media_ids, $this->settings);
            }
            $moments_type = $filelist ? 'image' : 'text';
            if ($_GPC['title']) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['title'] = $_GPC['title'];
                $data['openid'] = $_W['fans']['from_user'];
                $data['username'] = $_W['fans']['nickname'];
                $data['avatar'] = $userinfo['avatar'];
                $data['name'] = $_GPC['name'];
                $data['weixin'] = $_GPC['weixin'];
                $data['body'] = $_GPC['body'];
                $data['time'] = TIMESTAMP;
                pdo_update('siyuan_cms_tougao', $data, array('id' => $id));
            }
            if ($filelist) {
                foreach ($filelist as $key => $value) {
                    $data = array();
                    $data['mid'] = $id;
                    $data['pic'] = $value['name'];
                    pdo_insert('siyuan_cms_tougao_img', $data);
                }
            }
            include $this->template('cms/tougao');
        }
    }
}
$obj = new Siyuan_Cms_doMobileTougao();
$obj->exec();