<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileVod extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '精彩视频';
        $do = 'vod';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,video FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $vod_fenlei = pdo_fetchall('SELECT id,name,displayorder FROM ' . tablename('siyuan_cms_vod_fenlei') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder DESC ,id DESC LIMIT 20");
        $psize = 10;
        if ($act == 'index') {
            $vod_flash = pdo_fetchall('SELECT id,flash,thumb,title FROM ' . tablename('siyuan_cms_vod') . " WHERE weid = '{$_W['uniacid']}' and flash = '1' ORDER BY id DESC LIMIT 5");
            $fenlei = pdo_fetchall('SELECT id,name,thumb FROM ' . tablename('siyuan_cms_vod_fenlei') . " WHERE weid = '{$_W['uniacid']}' and parentid = '0' and status = '0' ORDER BY displayorder DESC LIMIT 48");
            foreach ($fenlei as $re) {
                $sql = 'SELECT id,title,time,yuedu,pinglun,thumb,blei FROM ' . tablename('siyuan_cms_vod') . ' WHERE blei = :blei ORDER BY id DESC LIMIT 4';
                $params = array(':blei' => $re['id']);
                $mreply = pdo_fetchall($sql, $params);
                foreach ($mreply as $mre) {
                    $re['mreply'][$mre['id']]['title'] = $mre['title'];
                    $re['mreply'][$mre['id']]['id'] = $mre['id'];
                    $re['mreply'][$mre['id']]['time'] = $mre['time'];
                    $re['mreply'][$mre['id']]['yuedu'] = $mre['yuedu'];
                    $re['mreply'][$mre['id']]['pinglun'] = $mre['pinglun'];
                    $re['mreply'][$mre['id']]['thumb'] = $mre['thumb'];
                }
                $reply[] = $re;
            }
            include $this->template('vod/index');
        }
        if ($act == 'list') {
            $bid = intval($_GPC['bid']);
            if (!empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $list = pdo_fetchall('SELECT id,title,time,yuedu,pinglun,thumb,blei FROM ' . tablename('siyuan_cms_vod') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_vod') . " WHERE weid = '{$_W['weid']}' {$condition}");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            include $this->template('vod/list');
        }
        if ($act == 'vod_list') {
            $bid = intval($_GPC['bid']);
            if (!empty($bid)) {
                $condition = " AND blei = {$bid}";
            }
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $list = pdo_fetchall('SELECT id,title,time,yuedu,pinglun,thumb,blei FROM ' . tablename('siyuan_cms_vod') . " WHERE  weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_vod') . " WHERE weid = '{$_W['weid']}' {$condition}");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('vod/vod_list');
        }
        if ($act == 'pinglun_list') {
            $newsid = intval($_GPC['newsid']);
            $pindex = max(intval($_GPC['currentpage']), intval($_GPC['page']));
            $pinglun_list = pdo_fetchall('SELECT id,name,avatar,content,pid,time FROM ' . tablename('siyuan_cms_vod_pinglun') . " WHERE  uniacid = '{$_W['weid']}'  and newsid = '{$newsid}' and pid = '0' ORDER BY id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize);
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_vod_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$newsid}' and pid = '0'");
            $pager = pagination($total, $pindex, $psize);
            $pageend = ceil($total / $psize);
            if ($total / $psize != 0 && $total >= $psize) {
                $pageend++;
                json_encode(array('status' => '200'));
            } else {
                json_encode(array('status' => '100'));
            }
            include $this->template('vod/pinglun_list');
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $news = pdo_fetch('SELECT id,blei,video,title,yuedu,pinglun,content,fenxiang,url,thumb FROM ' . tablename('siyuan_cms_vod') . ' WHERE `id` = ' . $id);
            $title = $news['title'];
            $black_list = pdo_fetchcolumn('SELECT status FROM ' . tablename('siyuan_cms_black_list') . ' WHERE openid = :openid', array(':openid' => $openid));
            if ($black_list >= '1' || $openid == '') {
                $user = '0';
            }
            $list = pdo_fetchall('SELECT id,thumb,title,time,yuedu,pinglun FROM ' . tablename('siyuan_cms_vod') . " WHERE weid = '{$_W['weid']}' and blei = {$news['blei']} ORDER BY id DESC LIMIT 10");
            $pinglun_list = pdo_fetchall('SELECT id,name,avatar,content,pid,time FROM ' . tablename('siyuan_cms_vod_pinglun') . " WHERE uniacid = '{$_W['weid']}' and pid = '0' and newsid = '{$id}' ORDER BY id DESC LIMIT {$psize}");
            $total = pdo_fetchcolumn('SELECT COUNT(id) FROM ' . tablename('siyuan_cms_vod_pinglun') . " WHERE uniacid = '{$_W['weid']}' and newsid = '{$id}' and pid = '0'");
            if ($total % $psize == 0) {
                $total_page = $total / $psize;
            } else {
                $total_page = floor($total / $psize) + 1;
            }
            pdo_update('siyuan_cms_vod', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
            include $this->template('vod/news');
        }
        if ($act == 'form_pinglun') {
            $id = intval($_GPC['id']);
            $num = intval($_GPC['num']);
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $content = $_GPC['content'];
            if ($content) {
                $data = array();
                $data['uniacid'] = $_W['uniacid'];
                $data['newsid'] = $id;
                $data['pid'] = $pid;
                $data['name'] = $userinfo['nickname'];
                $data['openid'] = $openid;
                $data['avatar'] = $userinfo['avatar'];
                $data['content'] = $_GPC['content'];
                $data['status'] = 1;
                $data['time'] = TIMESTAMP;
                pdo_insert('siyuan_cms_vod_pinglun', $data);
                pdo_update('siyuan_cms_vod', array('pinglun' => $num + 1), array('id' => $id));
            }
            die(json_encode(array('status' => 1)));
        }
    }
}
$obj = new Siyuan_Cms_doMobileVod();
$obj->exec();