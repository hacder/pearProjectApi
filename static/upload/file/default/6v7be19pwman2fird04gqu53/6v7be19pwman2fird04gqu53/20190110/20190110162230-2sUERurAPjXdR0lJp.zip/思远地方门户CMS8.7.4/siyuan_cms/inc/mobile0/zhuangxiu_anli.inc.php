<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileZhuangxiu_Anli extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'anli_list';
        $title = '&#x88C5;&#x4FEE;&#x6848;&#x4F8B;';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color,tel FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_zhuangxiu_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'anli_list') {
        }
        if ($act == 'ajax_anli_list') {
            $page = intval($_GET['page']);
            $pagenum = 8;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT id,thumb,title,gongsi FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    $ajaxarr[] = array('url' => $this->createMobileUrl('zhuangxiu_anli', array('id' => $item['id'], 'act' => 'anli')), 'thumb' => $_W['attachurl'] . $item['thumb'], 'title' => $item['title'], 'gongsi' => $item['gongsi']);
                }
            }
            echo json_encode($ajaxarr);
        }
        if ($act == 'anli') {
            $id = intval($_GPC['id']);
            $anli = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_zhuangxiu_gongsi_anli') . ' WHERE `id` = ' . $id);
        }
        include $this->template('zhuangxiu/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileZhuangxiu_Anli();
$obj->exec();