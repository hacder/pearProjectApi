<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebHouse extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		if ($op == 'display') {
			if (!empty($_GPC['displayorder'])) {
				foreach ($_GPC['displayorder'] as $id => $displayorder) {
					pdo_update('siyuan_cms_house', array('displayorder' => $displayorder), array('id' => $id));
				}
				message('', 'refresh', 'success');
			}
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= ' AND title LIKE :keyword';
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			$list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_house') . " WHERE uniacid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id DESC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_house') . " WHERE uniacid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/house/house');
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_house') . ' WHERE `id` = ' . $id;
			$item = pdo_fetch($sql);
			$pics_temp = unserialize($item['descimgs']);
			$pics = array();
			if ($pics_temp) {
				foreach ($pics_temp as $pic) {
					array_push($pics, tomedia($pic));
				}
				$item['descimgs'] = $pics;
			}
			$huxing_temp = unserialize($item['huxingimgs']);
			$huxingpics = array();
			if ($huxing_temp) {
				foreach ($huxing_temp as $pic1) {
					array_push($huxingpics, tomedia($pic1));
				}
				$item['huxingimgs'] = $huxingpics;
			}
			$flash_temp = unserialize($item['flash']);
			$flashpics = array();
			if ($flash_temp) {
				foreach ($flash_temp as $pic1) {
					array_push($flashpics, tomedia($pic1));
				}
				$item['flash'] = $flashpics;
			}
			$sql = 'SELECT * FROM ' . tablename('siyuan_cms_house_kv') . ' WHERE `houseid` = ' . $id . ' ORDER BY displayorder ASC';
			$item['params'] = pdo_fetchAll($sql);
			$saler = pdo_fetch("select * from" . tablename('mc_mapping_fans') . "where uniacid='{$_W['uniacid']}' and openid = '{$item['openid']}'");
			if (checksubmit('submit')) {
				if (empty($_GPC['name'])) {
					message('楼盘名称不能为空，请重新输入！');
				}
				$data = array('uniacid' => $_W['uniacid'], 'name' => $_GPC['name'], 'price' => $_GPC['price'], 'phone' => $_GPC['phone'], 'fenji' => $_GPC['fenji'], 'openid' => $_GPC['openid'], 'address' => $_GPC['address'], 'opentime' => strtotime($_GPC['opentime']), 'province' => $_GPC['reside']['province'], 'city' => $_GPC['reside']['city'], 'district' => $_GPC['reside']['district'], 'hotmsg' => $_GPC['hotmsg'], 'youhui' => $_GPC['youhui'], 'zt' => $_GPC['zt'], 'thumb' => $_GPC['thumb'], 'fenji' => $_GPC['fenji'], 'fenxiang' => $_GPC['fenxiang'], 'video' => htmlspecialchars_decode($_GPC['video']), 'biaoti' => $_GPC['biaoti'], 'description' => htmlspecialchars_decode($_GPC['description']), 'createtime' => TIMESTAMP);
				$picpath = $_GPC['descimgs'];
				if (is_array($picpath) && !empty($picpath)) {
					$paths = array();
					foreach ($picpath as $p) {
						array_push($paths, $p[0]);
					}
					$data['descimgs'] = serialize($paths);
				}
				$hxpicpath = $_GPC['huxingimgs'];
				if (is_array($hxpicpath) && !empty($hxpicpath)) {
					$paths = array();
					foreach ($hxpicpath as $p) {
						array_push($paths, $p[0]);
					}
					$data['huxingimgs'] = serialize($paths);
				}
				$flashpath = $_GPC['flash'];
				if (is_array($flashpath) && !empty($flashpath)) {
					$paths = array();
					foreach ($flashpath as $p) {
						array_push($paths, $p[0]);
					}
					$data['flash'] = serialize($paths);
				}
				$geo = $_GPC['geo'];
				if (is_array($geo) && !empty($geo)) {
					$data['longitude'] = $geo['lng'];
					$data['latitude'] = $geo['lat'];
				}
				$house_id = $id;
				if (empty($id)) {
					pdo_insert('siyuan_cms_house', $data);
					$house_id = pdo_insertid();
				} else {
					unset($data['createtime']);
					pdo_update('siyuan_cms_house', $data, array('id' => $id));
				}
				$ids = array();
				if (isset($_GPC['params_key']) && $_GPC['params_key']) {
					foreach ($_GPC['params_key'] as $k => $v) {
						$data = array('uniacid' => $_W['uniacid'], 'houseid' => $house_id, 'key' => $_GPC['params_key'][$k], 'value' => $_GPC['params_value'][$k], 'displayorder' => $k);
						if (empty($_GPC['params_id'][$k])) {
							pdo_insert('siyuan_cms_house_kv', $data);
							$ids[] = pdo_insertid();
						} else {
							pdo_update('siyuan_cms_house_kv', $data, array('id' => $_GPC['params_id'][$k]));
							$ids[] = $_GPC['params_id'][$k];
						}
					}
				}
				$sql = 'DELETE FROM ' . tablename('siyuan_cms_house_kv') . ' WHERE houseid=:houseid';
				if (!empty($ids)) {
					$sql .= ' AND id NOT IN(' . implode(',', $ids) . ')';
					pdo_query($sql, array(':houseid' => $house_id));
				} else {
					pdo_query($sql, array(':houseid' => $house_id));
				}
				message('楼盘更新成功！', url('site/entry/house', array('op' => 'display', 'id' => $house_id, 'm' => 'siyuan_cms')), 'success');
			}
			include $this->template('web/house/house');
			die;
		} elseif ($op == 'params') {
			global $_W, $_GPC;
			include $this->template('web/house/house-params-new');
			die;
		} elseif ($op == 'tj') {
			$id = intval($_GPC['id']);
			$status = intval($_GPC['status']);
			pdo_update('siyuan_cms_house', array('tj' => $status), array('id' => $id));
			message('', referer(), 'success');
		} elseif ($op == 'delete') {
			$id = intval($_GPC['id']);
			$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_house') . " WHERE id = :id", array(':id' => $id));
			if (empty($row)) {
				message('抱歉，信息不存在或是已经被删除！');
			}
			pdo_delete('siyuan_cms_house', array('id' => $id));
			message('删除成功！', referer(), 'success');
			die;
		} elseif ($op == 'deletekv') {
			$id = intval($_GPC['id']);
			if ($id > 0) {
				pdo_delete('siyuan_cms_house_kv', array('id' => $id));
			}
			echo 'success';
		} elseif ($op == 'place') {
			$id = intval($_GPC['id']);
			if ($id) {
				$house = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_house') . " WHERE id = :id", array(':id' => $id));
				$api = pdo_fetch("SELECT place_key,place_body FROM " . tablename('siyuan_cms_api') . " WHERE weid = :weid ", array(':weid' => $_W['uniacid']));
				$data = array();
				$radius = 2000;
				$pagesize = 10;
				$querys = explode(' ', $api['place_body']);
				foreach ($querys as $q) {
					$url = "http://api.map.baidu.com/place/v2/search?query={$q}&location={$house['latitude']},{$house['longitude']}&radius={$radius}&output=json&ak={$api['place_key']}&page_size={$pagesize}";
					$ret = file_get_contents($url);
					$ret = json_decode($ret, true);
					foreach ($ret['results'] as &$val) {
						$data[$q][] = array('query' => $q, 'name' => $val['name'], 'address' => $val['address'], 'distance' => $this->siyuan_cms_get_distance($house['latitude'], $house['longitude'], $val['location']['lat'], $val['location']['lng']), 'location' => $val['location']);
					}
				}
				foreach ($data as $k => $v) {
					usort($data[$k], array($this, 'siyuan_cms_house_place_orderby'));
				}
				pdo_update('siyuan_cms_house', array('place' => iserializer($data)), array('id' => $house['id']));
				die(json_encode(array('status' => 1)));
			}
		} elseif ($op == 'deletelayout') {
			$id = intval($_GPC['id']);
			if ($id > 0) {
				$sql = "SELECT * FROM " . tablename('siyuan_cms_house_layout') . ' WHERE `id` = ' . $id;
				$item = pdo_fetch($sql);
				if (!empty($item)) {
					file_delete($item['img']);
					pdo_delete('lice_fangchan_layout', array('id' => $id));
				}
			}
			echo 'success';
		}
	}
	public function siyuan_cms_get_distance($lat1, $lng1, $lat2, $lng2)
	{
		$earthRadius = 6367000;
		$lat1 = $lat1 * pi() / 180;
		$lng1 = $lng1 * pi() / 180;
		$lat2 = $lat2 * pi() / 180;
		$lng2 = $lng2 * pi() / 180;
		$calcLongitude = $lng2 - $lng1;
		$calcLatitude = $lat2 - $lat1;
		$stepOne = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2);
		$stepTwo = 2 * asin(min(1, sqrt($stepOne)));
		$calculatedDistance = $earthRadius * $stepTwo;
		return round($calculatedDistance);
	}
	private function siyuan_cms_house_place_orderby($a, $b)
	{
		if (intval($a['distance']) == intval($b['distance'])) {
			return 0;
		}
		return intval($a['distance']) > intval($b['distance']) ? 1 : -1;
	}
}
$obj = new Siyuan_Cms_doWebHouse();
$obj->exec();