<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebReg extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_W, $_GPC;
		$host_ip = gethostbyname($_SERVER['HTTP_HOST']);
		$host = $_SERVER[HTTP_HOST];
		$host = strtolower($host);
		if (strpos($host, '/') !== false) {
			$parse = @parse_url($host);
			$host = $parse['host'];
		}
		$topleveldomaindb = array('com', 'edu', 'gov', 'int', 'mil', 'net', 'org', 'biz', 'info', 'pro', 'name', 'museum', 'coop', 'aero', 'xxx', 'idv', 'mobi', 'cc', 'me', 'top');
		$str = '';
		foreach ($topleveldomaindb as $v) {
			$str .= ($str ? '|' : '') . $v;
		}
		$matchstr = "[^\\.]+\\.(?:(" . $str . ")|\\w{2}|((" . $str . ")\\.\\w{2}))\$";
		if (preg_match("/" . $matchstr . "/ies", $host, $matchs)) {
			$host_url = $matchs['0'];
		} else {
			$host_url = $host;
		}
		$status = file_get_contents('http://s.semall365.cn/app/index.php?i=1&c=entry&do=cms_reg&m=siyuan_admin&url=' . $host_url . '&ip=' . $host_ip);
		include $this->template('web/cms/reg');
	}
}
$obj = new Siyuan_Cms_doWebReg();
$obj->exec();