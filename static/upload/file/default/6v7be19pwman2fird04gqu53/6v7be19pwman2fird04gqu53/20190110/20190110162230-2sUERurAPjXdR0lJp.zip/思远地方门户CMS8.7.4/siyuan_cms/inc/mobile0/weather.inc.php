<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileWeather extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '首页';
        $do = 'huodong';
        $url = 'https://api.thinkpage.cn/v3/weather/now.json?key=SA2T7LVBO8&location=beijing&language=zh-Hans&unit=c';
        $res = file_get_contents($url);
        echo $res;
        echo '<br><br><br><br><br>';
        echo $res[0]['results']['location']['name'];
    }
}
$obj = new Siyuan_Cms_doMobileWeather();
$obj->exec();