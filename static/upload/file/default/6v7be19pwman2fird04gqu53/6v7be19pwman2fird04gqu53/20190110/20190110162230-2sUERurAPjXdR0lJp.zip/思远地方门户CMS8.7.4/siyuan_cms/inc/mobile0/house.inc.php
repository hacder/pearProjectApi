  <?php 
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileHouse extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '&#x623F;&#x4EA7;';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        if ($act == 'index') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_house') . " WHERE uniacid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 8");
            $news = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_house_news') . " WHERE weid = '{$_W['uniacid']}' ORDER BY id DESC LIMIT 8");
        }
        if ($act == 'list') {
        }
        if ($act == 'ajax') {
            global $_GPC, $_W;
            $page = intval($_GET['page']);
            $pagenum = 8;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_house') . " WHERE uniacid = '{$_W['weid']}' ORDER BY displayorder DESC,id desc LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    if ($item['price'] != '0') {
                        $price = $item['price'] . '&#x5143;/&#x5E73;&#x7C73;';
                    } else {
                        $price = '&#x4E00;&#x623F;&#x4E00;&#x4EF7;';
                    }
                    $arr[] = array('url' => $this->createMobileUrl('house', array('id' => $item['id'], 'act' => 'news')), 'name' => $item['name'], 'hotmsg' => $item['hotmsg'], 'price' => $price, 'address' => $item['address'], 'thumb' => $_W['attachurl'] . $item['thumb']);
                }
                echo json_encode($arr);
            }
        }
        if ($act == 'news') {
            $id = intval($_GPC['id']);
            $house = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_house') . ' WHERE `id` = ' . $id);
            $house['kvs'] = pdo_fetchAll('SELECT * FROM ' . tablename('siyuan_cms_house_kv') . ' WHERE `houseid` = ' . $id . ' ORDER BY displayorder ASC');
            $xinwen = pdo_fetchall('SELECT id,title,yuedu,thumb,time FROM ' . tablename('siyuan_cms_house_news'));
        }
        if ($act == 'map') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_house') . ' WHERE `uniacid` = ' . $_W['uniacid'] . '  LIMIT 100');
        }
        if ($act == 'ajax_news') {
            $id = $_GPC['id'];
            $page = intval($_GET['page']);
            $pagenum = 10;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT id,thumb,laiyuan,title,yuedu,time,loupanid FROM ' . tablename('siyuan_cms_house_news') . " WHERE weid = '{$_W['weid']}' AND loupanid = {$id} ORDER BY id DESC LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    $ajaxarr[] = array('url' => $this->createMobileUrl('house', array('id' => $item['id'], 'act' => 'house_news')), 'thumb' => $_W['attachurl'] . $item['thumb'], 'title' => $item['title'], 'yuedu' => $item['yuedu'], 'laiyuan' => $item['laiyuan'], 'time' => date('m-d H:i', $item['time']));
                }
            }
            echo json_encode($ajaxarr);
        }
        if ($act == 'news_list') {
        }
        if ($act == 'ajax_list_news') {
            $id = $_GPC['id'];
            if (empty($id)) {
                $condition = '';
            } else {
                $condition .= " AND houseid = {$id}";
            }
            $page = intval($_GET['page']);
            $pagenum = 4;
            $start = ($page - 1) * $pagenum;
            $list = pdo_fetchall('SELECT id,thumb,laiyuan,title,yuedu,time FROM ' . tablename('siyuan_cms_house_news') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY id DESC LIMIT {$start}," . $pagenum . '');
            $info = array();
            if (!empty($list)) {
                foreach ($list as $item) {
                    $ajaxarr[] = array('url' => $this->createMobileUrl('house', array('id' => $item['id'], 'act' => 'house_news')), 'thumb' => $_W['attachurl'] . $item['thumb'], 'title' => $item['title'], 'yuedu' => $item['yuedu'], 'laiyuan' => $item['laiyuan'], 'time' => date('m-d H:i', $item['time']));
                }
            }
            echo json_encode($ajaxarr);
        }
        if ($act == 'loushu') {
            $id = intval($_GPC['id']);
            $sql = 'SELECT id,name,descimgs,biaoti,fenxiang FROM ' . tablename('siyuan_cms_house') . ' WHERE `id` = ' . $id;
            $item = pdo_fetch($sql);
            $pics_temp = unserialize($item['descimgs']);
            $pics = array();
            if ($pics_temp) {
                foreach ($pics_temp as $pic) {
                    array_push($pics, tomedia($pic));
                }
                $item['descimgs'] = $pics;
            }
        }
        if ($act == 'huxing') {
            $id = intval($_GPC['id']);
            $sql = 'SELECT id,name,huxingimgs,biaoti,fenxiang FROM ' . tablename('siyuan_cms_house') . ' WHERE `id` = ' . $id;
            $item = pdo_fetch($sql);
            $pics_temp = unserialize($item['huxingimgs']);
            $pics = array();
            if ($pics_temp) {
                foreach ($pics_temp as $pic) {
                    array_push($pics, tomedia($pic));
                }
                $item['huxingimgs'] = $pics;
            }
        }
        if ($act == 'house_news') {
            $id = intval($_GPC['id']);
            $news = pdo_fetch('SELECT id,title,time,laiyuan,yuedu,content,thumb,loupanid FROM ' . tablename('siyuan_cms_house_news') . ' WHERE `id` = ' . $id);
            pdo_update('siyuan_cms_house_news', array('yuedu' => $news['yuedu'] + 1), array('id' => $news['id']));
        }
        include $this->template('house/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileHouse();
$obj->exec();