<?php

defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doMobileSai extends Siyuan_CmsModuleSite
{
    public function __construct()
    {
        parent::__construct();
    }
    public function exec()
    {
        global $_W, $_GPC;
        $act = $_GPC['act'] ? $_GPC['act'] : 'index';
        $menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_menu') . " WHERE weid = '{$_W['uniacid']}' ORDER BY displayorder ASC LIMIT 30");
        $bottom_menu = pdo_fetchall('SELECT displayorder,thumb,url,title FROM ' . tablename('siyuan_cms_bottom_menu') . " WHERE weid = '{$_W['uniacid']}' and xian = 1 ORDER BY displayorder ASC LIMIT 5");
        $flash = pdo_fetchall('SELECT attachment,url FROM ' . tablename('siyuan_cms_flash') . " WHERE weid = '{$_W['weid']}' ORDER BY id DESC LIMIT 5");
        $set = pdo_fetch('SELECT name,ad,logo,qr,color FROM ' . tablename('siyuan_cms_setting') . ' WHERE weid = :weid ', array(':weid' => $_W['uniacid']));
        $id = intval($_GPC['id']);
        $sai = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_sai') . ' WHERE `id` = ' . $id);
        if ($act == 'index') {
        }
        if ($act == 'news_list') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_sai_news') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 100");
        }
        if ($act == 'zanzhu') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_sai_zanzhu') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 100");
        }
        if ($act == 'sai') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_sai') . "WHERE `weid` = {$_W['weid']} ORDER BY displayorder ASC LIMIT 100");
        }
        if ($act == 'news') {
            $newsid = intval($_GPC['newsid']);
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_sai_news') . ' WHERE `id` = ' . $newsid);
        }
        if ($act == 'danye') {
            $newsid = intval($_GPC['newsid']);
            $news = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_sai_danye') . ' WHERE `id` = ' . $newsid);
        }
        if ($act == 'list') {
            $list = pdo_fetchall('SELECT * FROM ' . tablename('siyuan_cms_sai_menu') . " WHERE weid = '{$_W['uniacid']}' and sid = {$id} ORDER BY displayorder ASC LIMIT 30");
        }
        if ($act == 'baoming') {
            $userinfo = mc_oauth_userinfo();
            $openid = $_W['fans']['from_user'];
            $baoming = pdo_fetch('SELECT * FROM ' . tablename('siyuan_cms_sai_user') . " WHERE weid ={$_W['weid']} and sid= {$id} and openid = '{$openid}'");
            if (checksubmit('submit')) {
                $data = array('weid' => $_W['weid'], 'sid' => $id, 'avatar' => $userinfo['avatar'], 'status' => 1, 'baoming_1' => $_GPC['baoming_1'], 'baoming_2' => $_GPC['baoming_2'], 'baoming_3' => $_GPC['baoming_3'], 'baoming_4' => $_GPC['baoming_4'], 'baoming_5' => $_GPC['baoming_5'], 'baoming_6' => $_GPC['baoming_6'], 'baoming_7' => $_GPC['baoming_7'], 'baoming_8' => $_GPC['baoming_8'], 'username' => $userinfo['nickname'], 'openid' => $_W['fans']['from_user'], 'time' => TIMESTAMP);
                pdo_insert('siyuan_cms_sai_user', $data);
                $new_id = pdo_insertid();
                if (!$new_id) {
                    message('系统错误，请稍后重试', referer(), 'error');
                }
                message('您已成功报名...', $this->createMobileUrl('sai', array('act' => 'baoming', 'id' => $id)), 'success');
            }
        }
        include $this->template('sai/' . $act);
    }
}
$obj = new Siyuan_Cms_doMobileSai();
$obj->exec();