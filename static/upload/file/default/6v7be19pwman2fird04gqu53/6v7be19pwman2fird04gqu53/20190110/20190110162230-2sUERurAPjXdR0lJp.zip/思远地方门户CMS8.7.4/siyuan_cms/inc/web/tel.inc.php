<?php

//decode by QQ:270656184 http://www.yunlu99.com/
defined('IN_IA') or die('Access Denied');
class Siyuan_Cms_doWebTel extends Siyuan_CmsModuleSite
{
	public function __construct()
	{
		parent::__construct();
	}
	public function exec()
	{
		global $_GPC, $_W;
		$eid = intval($_GPC['eid']);
		$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
		$fenlei = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_tel_fenlei') . " WHERE weid = '{$_W['weid']}' ORDER BY parentid ASC, displayorder ASC, id ASC ", array(), 'id');
		if ($op == 'display') {
			if (!empty($_GPC['displayorder'])) {
				foreach ($_GPC['displayorder'] as $id => $displayorder) {
					pdo_update('siyuan_cms_tel', array('displayorder' => $displayorder), array('id' => $id));
				}
				message('', 'refresh', 'success');
			}
			$pindex = max(1, intval($_GPC['page']));
			$psize = 20;
			$condition = '';
			$params = array();
			if (!empty($_GPC['keyword'])) {
				$condition .= " AND title LIKE :keyword";
				$params[':keyword'] = "%{$_GPC['keyword']}%";
			}
			if (!empty($_GPC['cate_1'])) {
				$cid = intval($_GPC['cate_1']);
				$condition .= " AND blei = '{$cid}'";
			}
			$list = pdo_fetchall("SELECT * FROM " . tablename('siyuan_cms_tel') . " WHERE weid = '{$_W['weid']}' {$condition} ORDER BY displayorder DESC, id ASC LIMIT " . ($pindex - 1) * $psize . ',' . $psize, $params);
			$total = pdo_fetchcolumn('SELECT COUNT(*) FROM ' . tablename('siyuan_cms_tel') . " WHERE weid = '{$_W['weid']}' {$condition}", $params);
			$pager = pagination($total, $pindex, $psize);
			include $this->template('web/tel/tel');
		} elseif ($op == 'post') {
			$id = intval($_GPC['id']);
			$parent = array();
			$children = array();
			if (!empty($fenlei)) {
				$children = '';
				foreach ($fenlei as $cid => $cate) {
					if (!empty($cate['parentid'])) {
						$children[$cate['parentid']][] = $cate;
					} else {
						$parent[$cate['id']] = $cate;
					}
				}
			}
			if (!empty($id)) {
				$item = pdo_fetch("SELECT * FROM " . tablename('siyuan_cms_tel') . " WHERE id = :id", array(':id' => $id));
				if (empty($item)) {
					message('抱歉，视频不存在或是已经删除！', '', 'error');
				}
				$blei = $item['blei'];
				$slei = $item['slei'];
			}
			if (checksubmit('submit')) {
				if (empty($_GPC['title'])) {
					message('标题不能为空，请输入标题!');
				}
				$data = array('weid' => $_W['weid'], 'blei' => intval($_GPC['fenlei']['parentid']), 'slei' => intval($_GPC['fenlei']['childid']), 'title' => $_GPC['title'], 'displayorder' => $_GPC['displayorder'], 'tel' => $_GPC['tel'], 'address' => $_GPC['address'], 'weixin' => $_GPC['weixin'], 'status' => 1);
				if (empty($id)) {
					pdo_insert('siyuan_cms_tel', $data);
				} else {
					pdo_update('siyuan_cms_tel', $data, array('id' => $id));
				}
				message('更新成功！', url('site/entry/tel', array('op' => 'display', 'm' => 'siyuan_cms')), 'success');
			}
			include $this->template('web/tel/tel');
			die;
		} elseif ($op == 'dao_xls') {
			$weid = $_W['uniacid'];
			$file = $_FILES['fileName'];
			$max_size = "2000000";
			$fname = $file['name'];
			$ftype = strtolower(substr(strrchr($fname, '.'), 1));
			$uploadfile = $file['tmp_name'];
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				if (is_uploaded_file($uploadfile)) {
					if ($file['size'] > $max_size) {
						echo "Import file is too large";
						die;
					}
					if ($ftype == 'xls') {
						require_once '../framework/library/phpexcel/PHPExcel.php';
						$objReader = PHPExcel_IOFactory::createReader('Excel5');
						$objPHPExcel = $objReader->load($uploadfile);
						$sheet = $objPHPExcel->getSheet(0);
						$highestRow = $sheet->getHighestRow();
						for ($j = 2; $j <= $highestRow; $j++) {
							$title = trim($objPHPExcel->getActiveSheet()->getCell("A{$j}")->getValue());
							$tel = trim($objPHPExcel->getActiveSheet()->getCell("B{$j}")->getValue());
							$address = trim($objPHPExcel->getActiveSheet()->getCell("C{$j}")->getValue());
							$blei = trim($objPHPExcel->getActiveSheet()->getCell("D{$j}")->getValue());
							$slei = trim($objPHPExcel->getActiveSheet()->getCell("E{$j}")->getValue());
							$info = pdo_fetch("select * from" . tablename('siyuan_cms_tel') . "where tel ='{$tel}'");
							if (!empty($tel) && $tel !== $info['tel']) {
								pdo_insert('siyuan_cms_tel', array('status' => 1, 'title' => $title, 'tel' => $tel, 'blei' => $blei, 'slei' => $slei, 'address' => $address, 'weid' => $weid));
							} else {
								pdo_update('siyuan_cms_tel', array('status' => 1, 'title' => $title, 'tel' => $tel, 'blei' => $blei, 'slei' => $slei, 'address' => $address, 'weid' => $weid), array('tel' => $info['tel']));
							}
						}
					} else {
						message('文件后缀格式必须为.xls', referer(), 'success');
						die;
					}
				} else {
					message('未选择文件', referer(), 'success');
					die;
				}
			}
			message('导入成功！', referer(), 'success');
		} elseif ($op == 'status') {
			$id = intval($_GPC['id']);
			$status = $_GPC['status'];
			pdo_update('siyuan_cms_tel', array('status' => $status), array('id' => $id));
			message('', referer(), 'success');
		} elseif ($op == 'ding') {
			$id = intval($_GPC['id']);
			$status = $_GPC['status'];
			pdo_update('siyuan_cms_tel', array('ding' => $status), array('id' => $id));
			message('', referer(), 'success');
		} elseif ($op == 'daoru') {
			include $this->template('web/tel/tel');
		} elseif ($op == 'delete') {
			$id = intval($_GPC['id']);
			$row = pdo_fetch("SELECT id FROM " . tablename('siyuan_cms_tel') . " WHERE id = :id", array(':id' => $id));
			if (empty($row)) {
				message('抱歉，信息不存在或是已经被删除！');
			}
			pdo_delete('siyuan_cms_tel', array('id' => $id));
			message('', referer(), 'success');
			die;
		}
	}
}
$obj = new Siyuan_Cms_doWebTel();
$obj->exec();